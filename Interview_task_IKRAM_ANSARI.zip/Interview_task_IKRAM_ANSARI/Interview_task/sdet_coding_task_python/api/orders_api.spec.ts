/*

API Task 2 — Simple Automated Test
Write pseudo-code, or real code if you prefer, for one automated API test that validates:
GET /api/orders/ORD-1001 returns HTTP 200 and status = PAID
So for this task i am using here Playwright with typescript and complete the task.

*/
import { test, expect } from '@playwright/test';

test('Verify GET Order API', async ({ request }) => {

    const response = await request.get('/api/orders/ORD-1001');

    expect(response.status()).toBe(200);

    const body = await response.json();

    expect(body.order_id).toBe('ORD-1001');
    expect(body.status).toBe('PAID');
});


/*
Follow these steps Completed this task.

Sends a GET request to /api/orders/ORD-1001.
Verifies the response status code is 200 OK.
Parses the JSON response.
Confirms the order_id is ORD-1001.
Confirms the status is PAID.

*/

    