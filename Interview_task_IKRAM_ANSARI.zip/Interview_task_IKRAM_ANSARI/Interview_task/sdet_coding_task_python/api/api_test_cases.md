# Part C — Basic API Testing Thinking
You do not need to call a real API.
Assume there is an endpoint:
GET /api/orders/{order_id}
Example successful response:
{
  "order_id": "ORD-1001",
  "customer_id": "C001",
  "amount": 100.50,
  "currency": "GBP",
  "status": "PAID",
  "created_at": "2026-05-20T10:30:00Z"
}

## API Task 1 – Test Case Design

### Test Case 1

**Test Name:**
Verify successful retrieval of an existing order

**Input:**
GET /api/orders/ORD-1001

**Expected Result:**
- HTTP Status Code should be **200 OK**
- Response body should contain:
  - order_id = "ORD-1001"
  - customer_id = "C001"
  - amount = 100.50
  - currency = "GBP"
  - status = "PAID"
  - created_at = "2026-05-20T10:30:00Z"

**Why this test is useful:**
This verifies that the API successfully returns the correct details for a valid order ID. It is the primary positive test case.

---

### Test Case 2

**Test Name:**
Verify response for a non-existing order ID

**Input:**
GET /api/orders/ORD-9999

**Expected Result:**
- HTTP Status Code should be **404 Not Found**
- Response should contain an appropriate error message such as:
  - "Order not found"

**Why this test is useful:**
This ensures the API correctly handles requests for orders that do not exist and returns a proper error response.

---

### Test Case 3

**Test Name:**
Verify invalid order ID format

**Input:**
GET /api/orders/INVALID@123

**Expected Result:**
- HTTP Status Code should be **400 Bad Request**
- Response should contain a validation error message indicating an invalid order ID format.

**Why this test is useful:**
This verifies that the API validates input parameters and rejects invalid order IDs.

---

### Test Case 4

**Test Name:**
Verify all mandatory fields are present in the response

**Input:**
GET /api/orders/ORD-1001

**Expected Result:**
- HTTP Status Code should be **200 OK**
- Response should include the following fields:
  - order_id
  - customer_id
  - amount
  - currency
  - status
  - created_at
- None of these fields should be missing or null.

**Why this test is useful:**
This ensures that the API response schema remains consistent and includes all required fields.

---

### Test Case 5

**Test Name:**
Verify data values and data types

**Input:**
GET /api/orders/ORD-1001

**Expected Result:**
- HTTP Status Code should be **200 OK**
- amount should be numeric and greater than 0
- currency should be "GBP"
- status should be "PAID"
- created_at should follow ISO 8601 date-time format (YYYY-MM-DDTHH:MM:SSZ)

**Why this test is useful:**
This validates business rules and confirms that important fields contain valid values and correct data types.