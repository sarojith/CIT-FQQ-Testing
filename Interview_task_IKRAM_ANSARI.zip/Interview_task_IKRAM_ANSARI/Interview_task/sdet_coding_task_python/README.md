# Assignment Task

This repository contains my solutions for all four parts of the Assignment.

## Project Contents
# SDET_CODING_TASK_PYTHON
```

├── answers.sql
├── compare_headers.py
├── test_compare_headers.py
├── expected_orders.csv
├── actual_orders.csv
├── empty.csv
├── api
│   ├── api_test_cases.md
│   └── orders_api.spec.ts
└── README.md
```

---

## Part A – SQL

The SQL queries requested in the assignment are available in:

```
answers.sql
```

The queries were written using standard SQL syntax and cover all questions from Part A.

---

## Part B – CSV Header Comparison

### Language

Python 3

### Files

- `compare_headers.py`
- `test_compare_headers.py`

### Running the tool

From the project directory, run:

```bash
python compare_headers.py expected_orders.csv actual_orders.csv
```

The script compares the header row of both CSV files and reports whether they match. If there are differences, it identifies the missing or unexpected columns.

### Running the tests

Execute the unit tests with:

```bash
python -m unittest test_compare_headers.py
```

The test suite covers:

- Matching headers
- Different headers
- Missing columns
- Empty CSV files
- Invalid input scenarios

---

## Part C – API Testing

### API Test Cases

The API test cases are documented in:

```
api/api_test_cases.md
```

Five test cases were designed to validate the sample endpoint:

```
GET /api/orders/{order_id}
```

The scenarios include:

- Successful order retrieval
- Invalid order ID
- Non-existent order
- Mandatory response fields
- Response data validation

### Sample API Automation

A sample Playwright API test is available in:

```
api/orders_api.spec.ts
```

The example validates that:

- The endpoint returns HTTP 200
- The order status is `PAID`

Since the assignment specifies that a live API is not required, this file demonstrates the automation approach only.

---

## Assumptions

The following assumptions were made while completing the assignment:

- The CSV files always contain a header row.
- Header comparison is case-sensitive.
- Header order is considered during comparison.
- SQL queries are database-independent where possible.
- The API endpoint provided in Part C is hypothetical and used only for demonstrating test design and automation.

---
## AI Usage

ChatGPT was used only as a reference to clarify the assignment requirements, discuss possible approaches, and provide general suggestions. The implementation, logic, testing, and final solutions were completed, reviewed, and verified by me.