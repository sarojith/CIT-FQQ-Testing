Part A — SQL Exercise
You are given two tables representing yesterday’s and today’s product data.

Table: products_yesterday
product_id	product_name	price	status
1001	Coffee Mug	12.50	ACTIVE
1002	Laptop Stand	38.00	ACTIVE
1003	Wireless Mouse	19.99	ACTIVE
1004	Old Keyboard	29.99	DISCONTINUED
1005	Notebook	4.50	ACTIVE
1008	Desk Lamp	24.00	ACTIVE


Table: products_today
product_id	product_name	price	status
1001	Coffee Mug	12.50	ACTIVE
1002	Laptop Stand	35.00	ACTIVE
1003	Wireless Mouse	21.99	ACTIVE
1005	Notebook	4.50	INACTIVE
1006	Webcam	59.00	ACTIVE
1007	USB Cable	7.99	ACTIVE
1008	Desk Lamp	24.00	ACTIVE


Solution: -
SQL Task 1 — Price Changes
Write a SQL query to find products whose price changed from yesterday to today.
Expected output columns:
product_id, product_name, old_price, new_price

SELECT
    y.product_id,
    y.product_name,
    y.price AS old_price,
    t.price AS new_price
FROM products_yesterday y
INNER JOIN products_today t
ON y.product_id = t.product_id
WHERE y.price <> t.price;

Expected Result
product_id	product_name	old_price	new_price
1002	Laptop Stand	38.00	35.00
1003	Wireless Mouse	19.99	21.99

SQL Task 2 — New Products
Write a SQL query to find products that are new today, meaning they exist in products_today but not in products_yesterday.
Expected output columns:
product_id, product_name, price, status


SELECT
    t.product_id,
    t.product_name,
    t.price,
    t.status
FROM products_today t
LEFT JOIN products_yesterday y
ON t.product_id = y.product_id
WHERE y.product_id IS NULL;

Expected Result
product_id	product_name	price	status
1006	Webcam	59.00	ACTIVE
1007	USB Cable	7.99	ACTIVE

SQL Task 3 — Missing Products
Write a SQL query to find products that existed yesterday but are missing today.
Expected output columns:
product_id, product_name, price, status


SELECT
    y.product_id,
    y.product_name,
    y.price,
    y.status
FROM products_yesterday y
LEFT JOIN products_today t
ON y.product_id = t.product_id
WHERE t.product_id IS NULL;

Expected Result
product_id	product_name	price	status
1004	Old Keyboard	29.99	DISCONTINUED

SQL Task 4 — Status Changes
Write a SQL query to find products whose status changed from yesterday to today.
Expected output columns:
product_id, product_name, old_status, new_status


SELECT
    y.product_id,
    y.product_name,
    y.status AS old_status,
    t.status AS new_status
FROM products_yesterday y
INNER JOIN products_today t
ON y.product_id = t.product_id
WHERE y.status <> t.status;

Expected Result
product_id	product_name	old_status	new_status
1005	Notebook	ACTIVE	INACTIVE


SQL Task 5 — Short Explanation
1. Why did you use INNER JOIN, LEFT JOIN, NOT EXISTS, or another approach?
2. What would change if product_id was not unique?
3. What issue could happen if price or status can be NULL?


1. INNER JOIN is used when comparing products that exist in both tables, such as price changes and status changes.

LEFT JOIN is used to find products that exist in one table but not in the other, such as new products and missing products.

2. If product_id was not unique, the joins could return duplicate rows because one product could match multiple records. In that case, a unique key or additional columns would be needed to correctly identify each product.

3. If price or status contains NULL values, comparisons using <> may not return expected results because NULL represents an unknown value. Functions such as COALESSE or explicit NULL checks can be used to handle these cases.


