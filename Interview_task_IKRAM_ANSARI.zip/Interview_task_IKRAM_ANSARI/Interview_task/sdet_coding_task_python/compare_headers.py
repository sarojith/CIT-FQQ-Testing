import sys
import os


def read_headers(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Error: '{file_path}' does not exist.")

    with open(file_path, "r") as file:
        first_line = file.readline()

    if not first_line:
        raise ValueError(f"Error: '{file_path}' is empty.")

    
    headers = [header.strip() for header in first_line.strip().split(",")]

    
    if all(header == "" for header in headers):
        raise ValueError(f"Error: '{file_path}' has no valid headers.")

    return headers


def compare_headers(expected, actual):
    only_expected = [h for h in expected if h not in actual]
    only_actual = [h for h in actual if h not in expected]
    common = [h for h in expected if h in actual]

    actual_common = [h for h in actual if h in common]

    same_order = common == actual_common

    return only_expected, only_actual, common, same_order


def main():
    
    if len(sys.argv) != 3:
        print("Usage:")
        print("python compare_headers.py expected_orders.csv actual_orders.csv")
        return

    expected_file = sys.argv[1]
    actual_file = sys.argv[2]

    try:
        expected_headers = read_headers(expected_file)
        actual_headers = read_headers(actual_file)

        only_expected, only_actual, common, same_order = compare_headers(
            expected_headers, actual_headers
        )

        print(f"\nOnly in {expected_file}:")
        for header in only_expected:
            print(header)

        print(f"\nOnly in {actual_file}:")
        for header in only_actual:
            print(header)

        print("\nCommon headers:")
        for header in common:
            print(header)

        print("\nCommon headers in same relative order:")
        print(same_order)

    except Exception as error:
        print(error)


if __name__ == "__main__":
    main()