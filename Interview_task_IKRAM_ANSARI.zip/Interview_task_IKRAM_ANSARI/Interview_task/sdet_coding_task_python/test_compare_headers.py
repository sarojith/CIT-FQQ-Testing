from compare_headers import compare_headers

def test_identical_headers():
    expected = ["id", "name", "age"]
    actual = ["id", "name", "age"]
    _, _, _, same_order = compare_headers(expected, actual)
    assert same_order is True
    print("✓ Test 1 Passed")

def test_missing_header():
    expected = ["id", "name", "age"]
    actual = ["id", "name"]
    only_expected, _, _, _ = compare_headers(expected, actual)
    assert only_expected == ["age"]
    print("✓ Test 2 Passed")

def test_extra_spaces():
    expected = [" id ", " name ", " age "]
    actual = ["id", "name", "age"]

    expected = [h.strip() for h in expected]
    actual = [h.strip() for h in actual]

    _, _, common, _ = compare_headers(expected, actual)
    assert common == ["id", "name", "age"]
    print("✓ Test 3 Passed")

def test_different_order():
    expected = ["id", "name", "age"]
    actual = ["name", "id", "age"]

    _, _, _, same_order = compare_headers(expected, actual)
    assert same_order is False
    print("✓ Test 4 Passed")

test_identical_headers()
test_missing_header()
test_extra_spaces()
test_different_order()

print("\nAll tests passed successfully!")