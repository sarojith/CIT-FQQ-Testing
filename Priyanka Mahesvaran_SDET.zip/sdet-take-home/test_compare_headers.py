#!/usr/bin/env python3
"""
test_compare_headers.py

Simple unittest-based tests for compare_headers.py.

Run with:
    python -m unittest test_compare_headers.py -v
or:
    python test_compare_headers.py
"""

import os
import tempfile
import unittest

from compare_headers import (
    HeaderReadError,
    compare_headers,
    read_header_row,
)


def make_temp_csv(content, newline=""):
    """Helper: writes content to a temp file and returns its path."""
    fd, path = tempfile.mkstemp(suffix=".csv")
    with os.fdopen(fd, "w", newline=newline) as f:
        f.write(content)
    return path


class TestReadHeaderRow(unittest.TestCase):
    def test_missing_file_path_argument_is_handled_by_main(self):
        # main() checks argv length; read_header_row itself just needs a path.
        # Covered separately via CLI-level behavior; here we confirm a
        # nonexistent path raises a clear error.
        with self.assertRaises(HeaderReadError):
            read_header_row("this_file_does_not_exist.csv")

    def test_empty_csv_file_raises_error(self):
        path = make_temp_csv("")
        try:
            with self.assertRaises(HeaderReadError):
                read_header_row(path)
        finally:
            os.remove(path)

    def test_header_row_with_no_valid_headers_raises_error(self):
        # A row of only commas/whitespace has no real header names.
        path = make_temp_csv(" , , ,\n")
        try:
            with self.assertRaises(HeaderReadError):
                read_header_row(path)
        finally:
            os.remove(path)

    def test_headers_with_extra_spaces_are_trimmed(self):
        path = make_temp_csv("order_id,  customer_id ,amount \n")
        try:
            headers = read_header_row(path)
            self.assertEqual(headers, ["order_id", "customer_id", "amount"])
        finally:
            os.remove(path)

    def test_windows_line_endings_are_handled(self):
        path = make_temp_csv("order_id,customer_id,amount\r\nignored_second_line\r\n")
        try:
            headers = read_header_row(path)
            self.assertEqual(headers, ["order_id", "customer_id", "amount"])
        finally:
            os.remove(path)


class TestCompareHeaders(unittest.TestCase):
    def test_identical_headers(self):
        expected = ["order_id", "customer_id", "amount"]
        actual = ["order_id", "customer_id", "amount"]
        result = compare_headers(expected, actual)
        self.assertEqual(result["only_in_expected"], [])
        self.assertEqual(result["only_in_actual"], [])
        self.assertEqual(result["common"], expected)
        self.assertTrue(result["same_relative_order"])

    def test_one_header_missing_in_actual(self):
        expected = ["order_id", "customer_id", "amount"]
        actual = ["order_id", "customer_id"]
        result = compare_headers(expected, actual)
        self.assertEqual(result["only_in_expected"], ["amount"])
        self.assertEqual(result["only_in_actual"], [])
        self.assertEqual(result["common"], ["order_id", "customer_id"])
        self.assertTrue(result["same_relative_order"])

    def test_headers_present_but_in_different_order(self):
        expected = ["order_id", "customer_id", "amount"]
        actual = ["amount", "order_id", "customer_id"]
        result = compare_headers(expected, actual)
        self.assertEqual(set(result["common"]), {"order_id", "customer_id", "amount"})
        self.assertFalse(result["same_relative_order"])

    def test_exercise_fixture_files(self):
        # End-to-end check against the actual exercise fixtures, matching
        # the "Expected Console Output" section of the brief.
        expected_headers = read_header_row("expected_orders.csv")
        actual_headers = read_header_row("actual_orders.csv")
        result = compare_headers(expected_headers, actual_headers)

        self.assertEqual(
            result["only_in_expected"], ["amount", "created_at", "country"]
        )
        self.assertEqual(
            result["only_in_actual"],
            ["total_amount", "processed_at", "country_code"],
        )
        self.assertEqual(
            result["common"], ["order_id", "customer_id", "currency", "status"]
        )
        self.assertTrue(result["same_relative_order"])


if __name__ == "__main__":
    unittest.main()
