-- Part A - SQL Exercise
-- Tables: products_yesterday, products_today

-- Task 1: Price Changes
SELECT t.product_id, t.product_name, y.price AS old_price, t.price AS new_price
FROM products_today t
JOIN products_yesterday y ON t.product_id = y.product_id
WHERE t.price <> y.price;

-- Task 2: New Products (in today but not yesterday)
SELECT t.product_id, t.product_name, t.price, t.status
FROM products_today t
LEFT JOIN products_yesterday y ON t.product_id = y.product_id
WHERE y.product_id IS NULL;

-- Task 3: Missing Products (in yesterday but not today)
SELECT y.product_id, y.product_name, y.price, y.status
FROM products_yesterday y
LEFT JOIN products_today t ON y.product_id = t.product_id
WHERE t.product_id IS NULL;

-- Task 4: Status Changes
SELECT t.product_id, t.product_name, y.status AS old_status, t.status AS new_status
FROM products_today t
JOIN products_yesterday y ON t.product_id = y.product_id
WHERE t.status <> y.status;

-- Task 5: Short Explanation
-- 1. Why JOIN / LEFT JOIN?
--    INNER JOIN (JOIN) is used for Tasks 1 and 4 because both compare a
--    value for a product that must exist in BOTH tables (price/status
--    changes only make sense for products present on both days).
--    LEFT JOIN is used for Tasks 2 and 3 because they need to find rows
--    that exist on one side but NOT the other - the LEFT JOIN plus an
--    IS NULL check on the right-hand table's key is what surfaces that
--    "missing on the other side" condition.
--
-- 2. What would change if product_id was not unique?
--    The joins would produce a cartesian-style multiplication of rows
--    for any product_id appearing more than once in either table,
--    producing duplicate or misleading comparison rows. A dedup step
--    (e.g. picking one row per product_id, or including additional
--    columns to distinguish rows) would be needed before comparing.
--
-- 3. What issue could happen if price or status can be NULL?
--    Standard SQL comparisons (<>, =) return NULL (unknown), not TRUE,
--    when either side is NULL - so a genuine change from a real value
--    to NULL (or vice versa) would silently be excluded from the
--    result set. Handling this correctly requires NULL-safe comparisons,
--    e.g. using IS DISTINCT FROM instead of <>, or explicit
--    (t.price <> y.price OR (t.price IS NULL) <> (y.price IS NULL)) logic.
