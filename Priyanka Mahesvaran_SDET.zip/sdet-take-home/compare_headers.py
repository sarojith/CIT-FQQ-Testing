#!/usr/bin/env python3
"""
compare_headers.py

Compares the header row of two CSV files.

Usage:
    python compare_headers.py <expected_csv_path> <actual_csv_path>

This intentionally avoids a full CSV parsing library. The exercise input
is a simple, single-line header row with no quoted/escaped commas, so a
plain split on "," is sufficient and keeps the logic easy to read.
"""

import os
import sys


class HeaderReadError(Exception):
    """Raised when a header row cannot be read/parsed from a file."""
    pass


def read_header_row(path):
    """
    Reads only the first line of the given file and returns it as a list
    of trimmed, non-empty header names.

    Raises HeaderReadError with a human-readable message for:
      - file not found
      - empty file
      - header row with no valid (non-empty) headers
    """
    if not os.path.exists(path):
        raise HeaderReadError(f"File not found: {path}")

    if not os.path.isfile(path):
        raise HeaderReadError(f"Not a file: {path}")

    with open(path, "r", newline="") as f:
        first_line = f.readline()

    # Strip trailing newline characters (handles \n and \r\n)
    first_line = first_line.rstrip("\r\n")

    if first_line == "":
        raise HeaderReadError(f"File is empty (no header row found): {path}")

    raw_headers = first_line.split(",")
    headers = [h.strip() for h in raw_headers]
    headers = [h for h in headers if h != ""]

    if not headers:
        raise HeaderReadError(
            f"Header row exists but contains no valid headers: {path}"
        )

    return headers


def compare_headers(expected_headers, actual_headers):
    """
    Compares two lists of headers and returns a dict describing:
      - only_in_expected: headers present only in expected
      - only_in_actual: headers present only in actual
      - common: headers present in both (in expected's order)
      - same_relative_order: whether the common headers appear in the
        same relative order in both lists
    """
    expected_set = set(expected_headers)
    actual_set = set(actual_headers)

    only_in_expected = [h for h in expected_headers if h not in actual_set]
    only_in_actual = [h for h in actual_headers if h not in expected_set]
    common = [h for h in expected_headers if h in actual_set]

    # Relative order check: filter each original list down to just the
    # common headers, preserving each file's own ordering, then compare.
    expected_common_order = [h for h in expected_headers if h in actual_set]
    actual_common_order = [h for h in actual_headers if h in expected_set]
    same_relative_order = expected_common_order == actual_common_order

    return {
        "only_in_expected": only_in_expected,
        "only_in_actual": only_in_actual,
        "common": common,
        "same_relative_order": same_relative_order,
    }


def print_report(expected_path, actual_path, result):
    print(f"Only in {os.path.basename(expected_path)}:")
    if result["only_in_expected"]:
        for h in result["only_in_expected"]:
            print(f"  {h}")
    else:
        print("  (none)")

    print()
    print(f"Only in {os.path.basename(actual_path)}:")
    if result["only_in_actual"]:
        for h in result["only_in_actual"]:
            print(f"  {h}")
    else:
        print("  (none)")

    print()
    print("Common headers:")
    if result["common"]:
        for h in result["common"]:
            print(f"  {h}")
    else:
        print("  (none)")

    print()
    print("Common headers in same relative order:")
    print(f"  {str(result['same_relative_order']).lower()}")


def main(argv):
    if len(argv) != 3:
        print(
            "Usage: python compare_headers.py <expected_csv_path> <actual_csv_path>",
            file=sys.stderr,
        )
        return 1

    expected_path, actual_path = argv[1], argv[2]

    try:
        expected_headers = read_header_row(expected_path)
        actual_headers = read_header_row(actual_path)
    except HeaderReadError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    result = compare_headers(expected_headers, actual_headers)
    print_report(expected_path, actual_path, result)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
