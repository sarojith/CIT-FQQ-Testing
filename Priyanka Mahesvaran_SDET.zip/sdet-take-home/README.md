# SDET Take-Home Exercise

## 1. Language Used

Python 3 (standard library only — no third-party CSV or test-framework
dependencies were used).

## 2. How to Run the CSV Comparison Tool

```bash
python compare_headers.py expected_orders.csv actual_orders.csv
```

Example output:

```
Only in expected_orders.csv:
  amount
  created_at
  country

Only in actual_orders.csv:
  total_amount
  processed_at
  country_code

Common headers:
  order_id
  customer_id
  currency
  status

Common headers in same relative order:
  true
```

Error handling:
- Running with fewer/more than 2 arguments prints a usage message and exits with a non-zero status.
- A path that doesn't exist prints `Error: File not found: <path>` and exits non-zero.
- An empty file prints `Error: File is empty (no header row found): <path>` and exits non-zero.
- A header row containing only commas/whitespace prints `Error: Header row exists but contains no valid headers: <path>` and exits non-zero.

## 3. How to Run the Tests

```bash
python -m unittest test_compare_headers.py -v
```

There are 9 tests covering:
1. Identical headers
2. A header missing on one side
3. Headers with extra whitespace (trimmed correctly)
4. Windows (`\r\n`) line endings
5. Common headers present but in a different relative order
6. An empty CSV file
7. A header row with no valid headers
8. A missing/nonexistent file path
9. An end-to-end check against the actual `expected_orders.csv` / `actual_orders.csv` fixtures, matching the sample output in the brief

## 4. SQL Answers

See [`answers.sql`](./answers.sql) for the four queries (price changes, new
products, missing products, status changes).

**Short explanation (SQL Task 5):**

1. **Why JOIN / LEFT JOIN?** `INNER JOIN` is used for the price-change and
   status-change queries because both compare a value for a product that
   must exist in *both* tables. `LEFT JOIN` (with an `IS NULL` check on the
   right-hand key) is used for the new-products and missing-products
   queries because those need to find rows that exist on one side but not
   the other.
2. **If `product_id` was not unique:** the joins would multiply rows for
   any duplicated `product_id`, producing duplicate or misleading
   comparison rows. A dedup step (or extra columns to disambiguate) would
   be needed first.
3. **If `price` or `status` can be `NULL`:** `<>`/`=` return `NULL`
   (unknown) rather than `TRUE` when either side is `NULL`, so a real
   change to/from `NULL` would silently be excluded. This needs a
   NULL-safe comparison, e.g. `IS DISTINCT FROM`, or explicit
   `IS NULL` handling.

## 5. API Test Cases

**API Task 1 — Test Case Design**

| # | Test name | Input | Expected result | Why this test is useful |
|---|---|---|---|---|
| 1 | Valid order retrieval | `GET /api/orders/ORD-1001` | HTTP 200, correct fields returned | Confirms the happy path works |
| 2 | Invalid order ID | `GET /api/orders/ORD-9999` | HTTP 404 | Ensures proper error handling for a non-existent order |
| 3 | Field validation | `GET /api/orders/ORD-1001` | `amount` is numeric, `currency` is a valid ISO code | Data integrity check on the response body |
| 4 | Status value validation | `GET /api/orders/ORD-1001` | `status` matches an allowed value (`PAID`, `PENDING`, etc.) | Business rule validation |
| 5 | Response time | `GET /api/orders/ORD-1001` | Response time < 500ms | Confirms endpoint performance/efficiency |

**API Task 2 — Simple Automated Test**

```python
import requests

BASE_URL = "https://api.example.com"

def test_get_order_returns_paid_status():
    response = requests.get(f"{BASE_URL}/api/orders/ORD-1001")
    assert response.status_code == 200, (
        f"Expected 200, got {response.status_code}"
    )
    body = response.json()
    assert body["status"] == "PAID", (
        f"Expected status PAID, got {body.get('status')}"
    )
```


## 6. Assumptions Made

- The CSV files in this exercise have a simple, single header row with no quoted fields or embedded commas, so a plain `split(",")` is sufficient and a full CSV parser was intentionally avoided, per the brief.
- "Same relative order" for common headers means: taking only the common headers from each file, in the order they appear in that file, the two resulting sequences are identical.
- Header comparison is case-sensitive and treats headers as plain strings after trimming whitespace (no normalization of case or underscores/spaces).
- Only the first line of each file is read; the rest of the file is never opened or parsed, per the brief's instruction to read only the header row.

## 7. AI Usage Statement

AI tool used: **Claude** (Anthropic).

- **Part A (SQL)** and **Part C (API testing)** were written by the candidate without AI assistance.
- **Part B (CSV header comparison tool, tests)** and **Part D (this README)** were produced with Claude's help: Claude wrote the initial `compare_headers.py` implementation, `test_compare_headers.py` test suite, and the README structure/wording based on the exercise brief, then verified the tool's output and test results by running them.
- What Claude got right: a working implementation matching the exact expected console output in the brief on the first pass, plus a reasonable initial test suite covering the scenarios listed in the brief (identical headers, missing header, extra whitespace, Windows line endings, reordered headers).
- What was reviewed/relied on as-is: the core comparison logic (`compare_headers()`), the header-reading/error-handling logic (`read_header_row()`), and the test cases were reviewed and run successfully before being accepted; no changes were needed to Claude's implementation.
- The full prompts and responses used to produce Part B and Part D are included in `AI_TRANSCRIPT.md`.

Candidate statement: I understand this solution, including the header-comparison and relative-order-checking logic, the error handling, and the test cases, and can explain, modify, or debug any part of it during the interview.

## Candidate acknowledgement

By submitting this exercise, I confirm that:
1. I have followed the AI usage rules.
2. If I used AI, I have included the full relevant AI transcript or equivalent usage record.
3. I understand the submitted solution.
4. I am able to explain, modify, and debug the solution during the interview.
5. I understand that failure to disclose AI use, or inability to explain the submitted work, may result in rejection.
