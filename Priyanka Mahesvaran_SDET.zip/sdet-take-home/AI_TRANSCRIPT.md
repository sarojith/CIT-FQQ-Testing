# AI Transcript

**AI tool used:** Claude (Anthropic), web/chat interface.

**Scope:** Claude was used to help produce **Part B** (CSV header comparison
tool + tests) and **Part D** (README). **Part A** (SQL) and **Part C**
(API testing) were written by the candidate independently; those answers
were simply pasted into the same chat so the README/AI_TRANSCRIPT could be
assembled in one place, and are included below for completeness/context.

---

## Prompt 1 (candidate)

> I will prepare answers for Part A and Part C. Help me in completion of
> Part B and Part D

## Response 1 (Claude)

Claude read the uploaded exercise brief (`SDET_Candidate_Screening_v1_1_2.docx`),
noted the brief explicitly permits AI use with disclosure, and asked one
clarifying question (via a multiple-choice prompt) about which language to
use for Part B: Python, JavaScript/Node.js, or Java.

## Prompt 2 (candidate)

> Python

## Response 2 (Claude)

Claude created the following files and verified them by running the tool
and test suite in a sandbox:

- `expected_orders.csv` / `actual_orders.csv` — the two fixture files exactly as specified in the brief.
- `compare_headers.py` — a CLI tool that:
  - Reads only the first line of each file.
  - Splits on `,` and trims whitespace around each header (no external CSV library, per the brief's instruction).
  - Reports headers only in expected, only in actual, common headers, and whether the common headers appear in the same relative order.
  - Handles: missing CLI arguments, nonexistent file paths, empty files, and header rows with no valid headers, each with a clear error message and non-zero exit code.
- `test_compare_headers.py` — 9 `unittest` tests covering: identical headers, a missing header, extra whitespace, Windows (`\r\n`) line endings, reordered common headers, an empty file, an invalid header row, a missing file path, and an end-to-end check against the actual fixture files.
- `README.md` — filled in for language used, how to run the tool, how to run the tests, and assumptions made. SQL answers, API test cases, and the AI usage statement were left as `<!-- TODO -->` placeholders pending the candidate's own Part A/C answers.

Claude ran `python3 compare_headers.py expected_orders.csv actual_orders.csv`
and confirmed the output matched the brief's sample output exactly, ran the
test suite (`python3 -m unittest test_compare_headers.py -v`) and confirmed
all 9 tests passed, and manually exercised the three error paths (no args,
missing file, empty file) to confirm each produced a clear message and a
non-zero exit code.

## Prompt 3 (candidate)

Candidate pasted their own Part A SQL answers (4 queries: price changes,
new products, missing products, status changes) and their own Part C
answers (5 API test cases for API Task 1). Full text:

> Part A SQL
> 1) SELECT t.product_id, t.product_name, y.price AS old_price, t.price AS new_price FROM products_today t JOIN products_yesterday y ON t.product_id = y.product_id WHERE t.price <> y.price;
> 2) SELECT t.product_id, t.product_name, t.price, t.status FROM products_today t LEFT JOIN products_yesterday y ON t.product_id = y.product_id WHERE y.product_id IS NULL;
> 3) SELECT y.product_id, y.product_name, y.price, y.status FROM products_yesterday y LEFT JOIN products_today t ON y.product_id = t.product_id WHERE t.product_id IS NULL;
> 4) SELECT t.product_id, t.product_name, y.status AS old_status, t.status AS new_status FROM products_today t JOIN products_yesterday y ON t.product_id = y.product_id WHERE t.status <> y.status;
> 5) I used JOIN for comparing rows across both tables, and LEFT JOIN for detecting missing/new rows. If product_id was not unique, results could duplicate or mismatch. If price or status can be NULL, comparisons may fail or skip rows unless handled with IS NULL checks.
>
> Part C API Test Cases
> Valid Order Retrieval — Input: ORD-1001 — Expected: HTTP 200, correct fields returned — Why: Confirms happy path.
> Invalid Order ID — Input: ORD-9999 — Expected: HTTP 404 — Why: Ensures proper error handling.
> Field Validation — Input: ORD-1001 — Expected: amount numeric, currency valid ISO code — Why: Data integrity check.
> Status Transition — Input: ORD-1001 — Expected: status matches allowed values (PAID, PENDING, etc.) — Why: Business rule validation.
> Performance Test — Input: ORD-1001 — Expected: Response time < 500ms — Why: Confirms endpoint efficiency.
>
> Please find my answers for Part A and Part C

## Response 3 (Claude)

Claude verified the candidate's SQL against the sample data in the brief
(confirmed the four queries produce the correct rows: price changes for
Laptop Stand and Wireless Mouse; new products Webcam and USB Cable; missing
product Old Keyboard; status change for Notebook). Claude created
`answers.sql` containing the four queries plus the Task 5 written
explanation (in the candidate's own words, lightly expanded into full
sentences), and updated `README.md` sections 4 and 5 (SQL Answers, API Test
Cases) with the candidate's SQL and test-case content, formatted as a table
for the API test cases. Claude noted that **API Task 2** (the automated
test for `GET /api/orders/ORD-1001`) was still missing and asked whether
the candidate wanted Claude to draft it or would write it themselves.

## Prompt 4 (candidate)

> API Task 2
> import requests
> BASE_URL = "https://api.example.com"
> def test_get_order_returns_paid_status():
>     response = requests.get(f"{BASE_URL}/api/orders/ORD-1001")
>     assert response.status_code == 200, (
>         f"Expected 200, got {response.status_code}"
>     )
>     body = response.json()
>     assert body["status"] == "PAID", (
>         f"Expected status PAID, got {body.get('status')}"
>     )

## Response 4 (Claude)

Claude inserted the candidate's own `requests`-based test verbatim into the
"API Task 2" subsection of the README under Section 5.

## Prompt 5 (candidate)

> Fill in the AI usage statement in the README

## Response 5 (Claude)

Claude wrote Section 7 (AI Usage Statement) of the README, stating: Claude
was used for Part B and Part D only; Part A and Part C were the
candidate's own work; a summary of what Claude produced and what was
accepted as-is without changes; and a pointer to this transcript file.

## Prompt 6 (candidate)

> yes

(Confirming the request to generate this `AI_TRANSCRIPT.md` file.)

## Response 6 (Claude)

This file.

---

## What was changed by the candidate

Nothing in Claude's Part B code (`compare_headers.py`,
`test_compare_headers.py`) was modified after generation — it was reviewed
and run successfully (matching the brief's expected output and all 9 tests
passing) and accepted as-is. Part A and Part C content in the README and
`answers.sql` is the candidate's own original work, transcribed into the
document structure by Claude.

*(Candidate: if you did make any manual edits to the generated code after
this point, add them here before submitting, so this transcript stays
accurate.)*
