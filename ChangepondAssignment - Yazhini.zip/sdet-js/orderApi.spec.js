const { test, expect } = require('@playwright/test');

/**
 * Part C - Basic API Testing Thinking
 * Endpoint under test: GET /api/orders/{order_id}
 *
 * Note:
 * The assignment states that a real API call is not required.
 * Therefore, this file implements the 5 API test cases using a lightweight mocked API client.
 * The same assertions can be moved to Playwright's request.get() when a real base URL is available.
 */

const mockOrders = {
  'ORD-1001': {
    order_id: 'ORD-1001',
    customer_id: 'C001',
    amount: 100.50,
    currency: 'GBP',
    status: 'PAID',
    created_at: '2026-05-20T10:30:00Z'
  },
  'ORD-1002': {
    order_id: 'ORD-1002',
    customer_id: 'C002',
    amount: 40.00,
    currency: 'GBP',
    status: 'PENDING',
    created_at: '2026-05-20T11:00:00Z'
  }
};

async function getOrderById(orderId) {
  if (!orderId || orderId.trim() === '') {
    return {
      status: 400,
      body: {
        error: 'Bad Request',
        message: 'order_id is required'
      }
    };
  }

  if (!/^ORD-\d{4}$/.test(orderId)) {
    return {
      status: 400,
      body: {
        error: 'Bad Request',
        message: 'Invalid order_id format'
      }
    };
  }

  const order = mockOrders[orderId];

  if (!order) {
    return {
      status: 404,
      body: {
        error: 'Not Found',
        message: `Order ${orderId} was not found`
      }
    };
  }

  return {
    status: 200,
    body: order
  };
}

test.describe('GET /api/orders/{order_id}', () => {
  test('TC01 - should return 200 and PAID status for a valid paid order', async () => {
    // Test name: Validate successful retrieval of a paid order
    // Input: GET /api/orders/ORD-1001
    // Expected result: HTTP 200 and response.status = PAID
    // Why useful: Confirms the happy-path behavior for a valid order ID and verifies the key business status field.

    const response = await getOrderById('ORD-1001');

    expect(response.status).toBe(200);
    expect(response.body.order_id).toBe('ORD-1001');
    expect(response.body.status).toBe('PAID');
  });

  test('TC02 - should return complete order details for a valid order', async () => {
    // Test name: Validate response contract for successful order retrieval
    // Input: GET /api/orders/ORD-1001
    // Expected result: HTTP 200 and response contains order_id, customer_id, amount, currency, status, created_at
    // Why useful: Ensures the API response schema contains all fields required by consuming systems.

    const response = await getOrderById('ORD-1001');

    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('order_id');
    expect(response.body).toHaveProperty('customer_id');
    expect(response.body).toHaveProperty('amount');
    expect(response.body).toHaveProperty('currency');
    expect(response.body).toHaveProperty('status');
    expect(response.body).toHaveProperty('created_at');
  });

  test('TC03 - should return 404 for a non-existing order ID', async () => {
    // Test name: Validate not found response for unavailable order
    // Input: GET /api/orders/ORD-9999
    // Expected result: HTTP 404 with a meaningful error message
    // Why useful: Verifies that the API handles valid-format but unavailable order IDs correctly.

    const response = await getOrderById('ORD-9999');

    expect(response.status).toBe(404);
    expect(response.body.error).toBe('Not Found');
    expect(response.body.message).toContain('ORD-9999');
  });

  test('TC04 - should return 400 for invalid order ID format', async () => {
    // Test name: Validate bad request response for invalid order ID format
    // Input: GET /api/orders/ABC123
    // Expected result: HTTP 400 with invalid format error message
    // Why useful: Confirms API input validation and prevents incorrect order identifiers from being processed.

    const response = await getOrderById('ABC123');

    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Bad Request');
    expect(response.body.message).toBe('Invalid order_id format');
  });

  test('TC05 - should validate data types and timestamp format for a successful response', async () => {
    // Test name: Validate response data types and created_at timestamp format
    // Input: GET /api/orders/ORD-1001
    // Expected result: amount is a number, currency is GBP, and created_at is ISO 8601 UTC format
    // Why useful: Ensures downstream systems receive data in the expected format for calculations, reporting, and audit usage.

    const response = await getOrderById('ORD-1001');

    expect(response.status).toBe(200);
    expect(typeof response.body.amount).toBe('number');
    expect(response.body.currency).toBe('GBP');
    expect(response.body.created_at).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/);
  });
});
