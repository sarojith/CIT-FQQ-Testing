## AI Tool Used

ChatGPT

## Purpose of AI Usage

AI was used as an assistance tool to help structure and prepare a JavaScript / NodeJS solution for solution Exercise.


## Prompt Used

```text
Create a JavaScript / NodeJS solution for the SDET technical exercise with clear implementation, validation, documentation, and AI usage disclosure.

The solution should include:
1. SQL answers for comparing products_yesterday and products_today tables.
2. A command-line CSV header comparison tool using JavaScript / NodeJS.
3. The CSV tool should accept two CSV file paths as input, read only the first row, split headers by comma, trim whitespace, compare headers, and print:
   - headers only in the expected file
   - headers only in the actual file
   - common headers
   - whether common headers are in the same relative order
4. Do not use a heavy CSV parsing library.
5. Add simple tests using NodeJS built-in assertions.
6. Include tests and error handling for:
   - missing file path argument
   - file does not exist
   - empty CSV file
   - header row exists but has no valid headers
7. Add API testing content for GET /api/orders/{order_id}, including five test cases and one simple automated API test using Playwright style.
8. Create a professional README.md with run instructions, SQL answers, API test cases, assumptions, and candidate acknowledgement.
```

## AI Response Relied On

ChatGPT provided a JavaScript / NodeJS project structure with the following files:

1. `compareHeaders.js` — command-line CSV header comparison tool.
2. `compareHeaders.test.js` — NodeJS assertion-based test file.
3. `expected_orders.csv` — sample expected CSV input.
4. `actual_orders.csv` — sample actual CSV input.
5. `answers.sql` — SQL answers for the product comparison tasks.
6. `api-test-cases.md` — API test case design and sample automated API test.
7. `apiOrderTest.playwright.js` — sample Playwright API test file.
8. `README.md` — project documentation and submission explanation.

## Suggestions Accepted

I accepted the following AI-generated suggestions:

1. Use JavaScript / NodeJS for the CSV comparison utility.
2. Use NodeJS `fs` module to read the CSV files.
3. Read only the first line of each file because only headers need to be compared.
4. Split the header row by comma and trim whitespace around each header.
5. Use `Set` to identify headers only in expected, only in actual, and common headers.
6. Validate common header relative order using the positions of common headers in the actual header list.
7. Use NodeJS built-in `assert` for lightweight tests instead of adding a full test framework.
8. Use `INNER JOIN` for SQL price and status change queries.
9. Use `NOT EXISTS` for SQL new-product and missing-product queries.
10. Provide Playwright-style API test code for the automated API test example.

## Suggestions Rejected or Modified

1. No heavy CSV parsing library was added because the requirement states that the input is intentionally simple.
2. No complex automation framework was added because the assignment focuses on basic practical logic rather than framework design.
3. The README was kept concise and professional so that it can be reviewed easily.
4. The API automated test was kept as a sample because no actual API base URL was provided.

## Manual Review and Validation

I reviewed the final solution and validated the following:

1. The CSV comparison command runs successfully.
2. The test file runs successfully.
3. Missing argument error handling is covered.
4. File-not-found error handling is covered.
5. Empty file and invalid header row errors are covered.
6. The SQL answers match the required comparison scenarios.
7. The API test cases cover happy path, not found, invalid input, schema validation, and authorization.
8. The Playwright API test validates HTTP `200` and `status = PAID` for `ORD-1001`.

## Commands Used for Validation

```bash
node compareHeaders.js expected_orders.csv actual_orders.csv
node compareHeaders.test.js
```

Both commands completed successfully.
