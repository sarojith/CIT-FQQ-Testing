# SDET Technical Exercise — JavaScript / NodeJS Solution

## 1. Overview

This repository contains the completed solution for the SDET technical exercise. The solution is intentionally simple, readable, and easy to execute from the command line.

The submission covers:

1. SQL queries for product comparison scenarios.
2. A JavaScript / NodeJS command-line utility to compare CSV headers.
3. Basic tests for the CSV header comparison logic and error handling.
4. API test case design for `GET /api/orders/{order_id}`.
5. A sample Playwright API test for a successful order lookup.
6. Assumptions and candidate acknowledgement.

## 2. Language Used

JavaScript / NodeJS

No heavy CSV parsing library is used. The CSV files are treated as simple inputs, so the implementation reads only the first line, splits it by comma, trims whitespace, and compares the resulting header values.

## 3. Project Structure

```text
sdet-take-home-js/
  README.md
  AI_TRANSCRIPT.md
  answers.sql
  expected_orders.csv
  actual_orders.csv
  compareHeaders.js
  compareHeaders.test.js
  api-test-cases.md
  apiOrderTest.playwright.js
  package.json
```

## 4. How to Run the CSV Header Comparison Tool

From the project folder, run:

```bash
node compareHeaders.js expected_orders.csv actual_orders.csv
```

Alternatively, run:

```bash
npm start
```

Expected console output:

```text
Only in expected_orders.csv:
amount
created_at
country

Only in actual_orders.csv:
total_amount
processed_at
country_code

Common headers:
order_id
customer_id
currency
status

Common headers in same relative order:
true
```

## 5. How to Run the Tests

From the project folder, run:

```bash
node compareHeaders.test.js
```

Alternatively, run:

```bash
npm test
```

Expected result:

```text
All tests passed.
```

The test file validates the following scenarios:

1. Two files with identical headers.
2. One header missing from the actual headers.
3. Headers containing extra spaces.
4. Windows line endings.
5. Common headers present in a different relative order.
6. Missing file path argument.
7. File does not exist.
8. Empty CSV file.
9. Header row exists but has no valid headers.

## 6. Part A — SQL Answers

### SQL Task 1 — Price Changes

```sql
SELECT
    t.product_id,
    t.product_name,
    y.price AS old_price,
    t.price AS new_price
FROM products_yesterday y
INNER JOIN products_today t
    ON y.product_id = t.product_id
WHERE y.price <> t.price;
```

Expected result based on the given data:

| product_id | product_name | old_price | new_price |
|---:|---|---:|---:|
| 1002 | Laptop Stand | 38.00 | 35.00 |
| 1003 | Wireless Mouse | 19.99 | 21.99 |

### SQL Task 2 — New Products

```sql
SELECT
    t.product_id,
    t.product_name,
    t.price,
    t.status
FROM products_today t
WHERE NOT EXISTS (
    SELECT 1
    FROM products_yesterday y
    WHERE y.product_id = t.product_id
);
```

Expected result based on the given data:

| product_id | product_name | price | status |
|---:|---|---:|---|
| 1006 | Webcam | 59.00 | ACTIVE |
| 1007 | USB Cable | 7.99 | ACTIVE |

### SQL Task 3 — Missing Products

```sql
SELECT
    y.product_id,
    y.product_name,
    y.price,
    y.status
FROM products_yesterday y
WHERE NOT EXISTS (
    SELECT 1
    FROM products_today t
    WHERE t.product_id = y.product_id
);
```

Expected result based on the given data:

| product_id | product_name | price | status |
|---:|---|---:|---|
| 1004 | Old Keyboard | 29.99 | DISCONTINUED |

### SQL Task 4 — Status Changes

```sql
SELECT
    t.product_id,
    t.product_name,
    y.status AS old_status,
    t.status AS new_status
FROM products_yesterday y
INNER JOIN products_today t
    ON y.product_id = t.product_id
WHERE y.status <> t.status;
```

Expected result based on the given data:

| product_id | product_name | old_status | new_status |
|---:|---|---|---|
| 1005 | Notebook | ACTIVE | INACTIVE |

### SQL Task 5 — Explanation

For price changes and status changes, I used `INNER JOIN` because these checks require the same `product_id` to exist in both yesterday and today tables. Once the matching product rows are joined, the old and new values can be compared directly.

For new products and missing products, I used `NOT EXISTS` because it clearly checks whether a matching `product_id` is absent in the other table. This approach is readable and avoids ambiguity that can happen with outer joins when nullable fields are involved.

If `product_id` was not unique, the current join could produce duplicate or incorrect comparison rows. In that case, I would first identify the correct unique business key. If no natural unique key exists, I would add additional matching criteria such as product name, effective date, source system, or use row-number logic to select the correct record before comparison. I would also add a duplicate validation query before running the comparison.

If `price` or `status` can be `NULL`, using `<>` may not detect changes correctly because SQL comparisons with `NULL` return unknown instead of true or false. In PostgreSQL or Redshift-style SQL, I would use `IS DISTINCT FROM` for null-safe comparison:

```sql
WHERE y.price IS DISTINCT FROM t.price;
```

```sql
WHERE y.status IS DISTINCT FROM t.status;
```

If the database does not support `IS DISTINCT FROM`, I would handle `NULL` explicitly using `COALESCE` or separate `IS NULL` checks.

## 7. Part B — CSV Header Comparison Tool

The tool performs the following steps:

1. Accepts two CSV file paths as command-line input.
2. Validates that both file paths are provided.
3. Validates that both files exist.
4. Validates that the CSV file is not empty.
5. Reads only the first row from each CSV file.
6. Splits the first row by comma.
7. Trims whitespace around each header.
8. Removes blank header values.
9. Compares expected and actual headers.
10. Prints headers only in the expected file, headers only in the actual file, common headers, and whether common headers appear in the same relative order.

### Error Handling Covered

The script handles the following error scenarios with clear messages:

1. Missing file path argument.
2. File does not exist.
3. Empty CSV file.
4. Header row exists but has no valid headers.

Example missing argument command:

```bash
node compareHeaders.js expected_orders.csv
```

Example output:

```text
Error: Missing file path argument. Usage: node compareHeaders.js expected_orders.csv actual_orders.csv
```

Example missing file command:

```bash
node compareHeaders.js expected_orders.csv missing_file.csv
```

Example output:

```text
Error: File does not exist: missing_file.csv
```

## 8. Part C — Basic API Testing Thinking

Endpoint:

```text
GET /api/orders/{order_id}
```

Example successful response:

```json
{
  "order_id": "ORD-1001",
  "customer_id": "C001",
  "amount": 100.50,
  "currency": "GBP",
  "status": "PAID",
  "created_at": "2026-05-20T10:30:00Z"
}
```

### API Task 1 — Test Case Design

| # | Test name | Input | Expected result | Why this test is useful |
|---:|---|---|---|---|
| 1 | Verify valid paid order details | `GET /api/orders/ORD-1001` | API returns HTTP `200`. Response body contains `order_id = ORD-1001`, `customer_id = C001`, `amount = 100.50`, `currency = GBP`, `status = PAID`, and a valid `created_at` value. | This validates the main successful flow of the endpoint. It confirms that a valid existing order can be retrieved and that the important business fields are returned correctly. |
| 2 | Verify non-existing order returns not found | `GET /api/orders/ORD-9999` | API returns HTTP `404`. Response body contains a clear error message such as `Order not found` or an equivalent not-found response. | This validates negative behavior when the order does not exist. It ensures the API does not return incorrect data or a misleading success response for an invalid resource. |
| 3 | Verify invalid order id format validation | `GET /api/orders/INVALID123` | API returns HTTP `400`. Response body contains a validation error indicating that the order id format is invalid. | This verifies input validation for the path parameter. It helps confirm that bad request data is rejected before business processing. |
| 4 | Verify response schema and data types for valid order | `GET /api/orders/ORD-1001` | API returns HTTP `200`. Response contains all mandatory fields with correct data types: `order_id` as string, `customer_id` as string, `amount` as number, `currency` as string, `status` as string, and `created_at` as ISO date-time string. | This protects the API contract. It is useful for regression testing because UI, reporting, and downstream integrations may fail if field names or data types change. |
| 5 | Verify unauthorized request is rejected | `GET /api/orders/ORD-1001` without a valid authorization token/header | API returns HTTP `401 Unauthorized` if authentication is missing, or HTTP `403 Forbidden` if the user is authenticated but does not have access. No sensitive order details should be returned. | This validates security behavior. It ensures that order information is not exposed to unauthenticated or unauthorized users. |

The same 5 test cases are also documented separately in `api-test-cases.md`.

### API Task 2 — Simple Automated API Test Using Playwright

```javascript
const { test, expect } = require('@playwright/test');

test('GET /api/orders/ORD-1001 should return HTTP 200 and status PAID', async ({ request }) => {
  const response = await request.get('/api/orders/ORD-1001');

  expect(response.status()).toBe(200);

  const responseBody = await response.json();
  expect(responseBody.order_id).toBe('ORD-1001');
  expect(responseBody.status).toBe('PAID');
});
```

The same test is also added in `apiOrderTest.playwright.js` as a separate reference file.

Note: This is a sample API test because no real API base URL is provided. In a real automation project, the base URL would be configured in `playwright.config.js`, environment variables, or an environment-specific configuration file.

## 9. Assumptions

1. The CSV files are simple and do not contain quoted commas in the header row.
2. Header comparison is case-sensitive. For example, `amount` and `Amount` are treated as different headers.
3. The first row of each CSV file is the header row.
4. `product_id` is assumed to be unique in both SQL tables.
5. SQL queries are written in ANSI-style SQL. For null-safe comparisons, PostgreSQL or Redshift-style `IS DISTINCT FROM` can be used.
6. The API endpoint is assumed to follow common REST status-code behavior such as `200`, `400`, `401`, `403`, and `404`.
7. The API automated test is provided as a sample because no actual API host or base URL is available.

## 10. AI Usage Statement

I used ChatGPT as an assistance tool to structure the solution, prepare the initial JavaScript implementation, create SQL queries, design API test cases, and format the README. I reviewed the generated content, validated the command-line script and tests, and understand how the submitted solution works.

The AI usage record is included in `AI_TRANSCRIPT.md`.

## 11. Candidate Acknowledgement

By submitting this exercise, I confirm that:

1. I have followed the AI usage rules.
2. If I used AI, I have included the full relevant AI transcript or equivalent usage record.
3. I understand the submitted solution.
4. I am able to explain, modify, and debug the solution during the interview.
5. I understand that failure to disclose AI use, or inability to explain the submitted work, may result in rejection.
