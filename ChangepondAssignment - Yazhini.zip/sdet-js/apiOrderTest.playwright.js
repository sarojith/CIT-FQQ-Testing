const { test, expect } = require('@playwright/test');

test('GET /api/orders/ORD-1001 should return HTTP 200 and status PAID', async ({ request }) => {
  const response = await request.get('/api/orders/ORD-1001');

  expect(response.status()).toBe(200);

  const responseBody = await response.json();
  expect(responseBody.order_id).toBe('ORD-1001');
  expect(responseBody.status).toBe('PAID');
});
