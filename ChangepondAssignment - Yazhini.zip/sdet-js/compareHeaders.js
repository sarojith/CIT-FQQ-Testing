const fs = require('fs');
const path = require('path');

function validateInputPaths(expectedFilePath, actualFilePath) {
  if (!expectedFilePath || !actualFilePath) {
    throw new Error('Missing file path argument. Usage: node compareHeaders.js expected_orders.csv actual_orders.csv');
  }
}

function readHeaders(filePath) {
  if (!filePath) {
    throw new Error('Missing file path argument. Please provide a valid CSV file path.');
  }

  if (!fs.existsSync(filePath)) {
    throw new Error(`File does not exist: ${filePath}`);
  }

  const content = fs.readFileSync(filePath, 'utf8');

  if (content.length === 0) {
    throw new Error(`Empty CSV file: ${filePath}`);
  }

  const firstLine = content.split(/\r?\n/)[0];
  const headers = firstLine
    .split(',')
    .map(header => header.trim())
    .filter(header => header.length > 0);

  if (headers.length === 0) {
    throw new Error(`Header row exists but has no valid headers: ${filePath}`);
  }

  return headers;
}

function compareHeaders(expectedHeaders, actualHeaders) {
  const expectedSet = new Set(expectedHeaders);
  const actualSet = new Set(actualHeaders);

  const onlyInExpected = expectedHeaders.filter(header => !actualSet.has(header));
  const onlyInActual = actualHeaders.filter(header => !expectedSet.has(header));
  const commonHeaders = expectedHeaders.filter(header => actualSet.has(header));

  const actualPositions = commonHeaders.map(header => actualHeaders.indexOf(header));
  const commonHeadersInSameRelativeOrder = actualPositions.every((position, index) => {
    return index === 0 || position > actualPositions[index - 1];
  });

  return {
    onlyInExpected,
    onlyInActual,
    commonHeaders,
    commonHeadersInSameRelativeOrder
  };
}

function compareCsvFiles(expectedFilePath, actualFilePath) {
  validateInputPaths(expectedFilePath, actualFilePath);

  const expectedHeaders = readHeaders(expectedFilePath);
  const actualHeaders = readHeaders(actualFilePath);

  return compareHeaders(expectedHeaders, actualHeaders);
}

function printList(title, values) {
  console.log(title);

  if (values.length === 0) {
    console.log('(none)');
    return;
  }

  values.forEach(value => console.log(value));
}

function runCli() {
  const [, , expectedFilePath, actualFilePath] = process.argv;

  try {
    const result = compareCsvFiles(expectedFilePath, actualFilePath);

    printList(`Only in ${path.basename(expectedFilePath)}:`, result.onlyInExpected);
    console.log('');
    printList(`Only in ${path.basename(actualFilePath)}:`, result.onlyInActual);
    console.log('');
    printList('Common headers:', result.commonHeaders);
    console.log('');
    console.log('Common headers in same relative order:');
    console.log(result.commonHeadersInSameRelativeOrder);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
}

if (require.main === module) {
  runCli();
}

module.exports = {
  validateInputPaths,
  readHeaders,
  compareHeaders,
  compareCsvFiles
};
