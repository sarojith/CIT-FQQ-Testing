const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const {
  validateInputPaths,
  readHeaders,
  compareHeaders,
  compareCsvFiles
} = require('./compareHeaders');

function writeTempCsv(fileName, content) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'header-test-'));
  const filePath = path.join(dir, fileName);
  fs.writeFileSync(filePath, content, 'utf8');
  return filePath;
}

function testIdenticalHeaders() {
  const result = compareHeaders(
    ['order_id', 'customer_id', 'amount'],
    ['order_id', 'customer_id', 'amount']
  );

  assert.deepStrictEqual(result.onlyInExpected, []);
  assert.deepStrictEqual(result.onlyInActual, []);
  assert.deepStrictEqual(result.commonHeaders, ['order_id', 'customer_id', 'amount']);
  assert.strictEqual(result.commonHeadersInSameRelativeOrder, true);
}

function testOneHeaderMissing() {
  const result = compareHeaders(
    ['order_id', 'customer_id', 'amount'],
    ['order_id', 'customer_id']
  );

  assert.deepStrictEqual(result.onlyInExpected, ['amount']);
  assert.deepStrictEqual(result.onlyInActual, []);
  assert.deepStrictEqual(result.commonHeaders, ['order_id', 'customer_id']);
  assert.strictEqual(result.commonHeadersInSameRelativeOrder, true);
}

function testExtraSpacesAreTrimmed() {
  const filePath = writeTempCsv('spaces.csv', ' order_id , customer_id , amount \n1,C001,100.50');
  const headers = readHeaders(filePath);

  assert.deepStrictEqual(headers, ['order_id', 'customer_id', 'amount']);
}

function testWindowsLineEndings() {
  const filePath = writeTempCsv('windows.csv', 'order_id,customer_id,amount\r\n1,C001,100.50');
  const headers = readHeaders(filePath);

  assert.deepStrictEqual(headers, ['order_id', 'customer_id', 'amount']);
}

function testCommonHeadersDifferentRelativeOrder() {
  const result = compareHeaders(
    ['order_id', 'customer_id', 'amount', 'status'],
    ['customer_id', 'order_id', 'amount', 'status']
  );

  assert.deepStrictEqual(result.commonHeaders, ['order_id', 'customer_id', 'amount', 'status']);
  assert.strictEqual(result.commonHeadersInSameRelativeOrder, false);
}

function testMissingFilePathArgument() {
  assert.throws(
    () => validateInputPaths('expected_orders.csv'),
    /Missing file path argument/
  );

  assert.throws(
    () => compareCsvFiles(undefined, 'actual_orders.csv'),
    /Missing file path argument/
  );
}

function testFileDoesNotExist() {
  assert.throws(
    () => readHeaders('file_that_does_not_exist.csv'),
    /File does not exist/
  );
}

function testEmptyFileError() {
  const filePath = writeTempCsv('empty.csv', '');
  assert.throws(() => readHeaders(filePath), /Empty CSV file/);
}

function testNoValidHeaderError() {
  const filePath = writeTempCsv('no-valid-headers.csv', ' , , \n1,2,3');
  assert.throws(() => readHeaders(filePath), /no valid headers/);
}

function runTests() {
  testIdenticalHeaders();
  testOneHeaderMissing();
  testExtraSpacesAreTrimmed();
  testWindowsLineEndings();
  testCommonHeadersDifferentRelativeOrder();
  testMissingFilePathArgument();
  testFileDoesNotExist();
  testEmptyFileError();
  testNoValidHeaderError();

  console.log('All tests passed.');
}

runTests();
