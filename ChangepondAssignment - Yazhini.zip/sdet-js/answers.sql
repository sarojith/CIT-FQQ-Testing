-- Part A — SQL Exercise
-- SQL dialect: ANSI-style SQL. These queries work in most relational databases with minor syntax changes if needed.

-- Task 1: Price Changes
SELECT
    t.product_id,
    t.product_name,
    y.price AS old_price,
    t.price AS new_price
FROM products_yesterday y
INNER JOIN products_today t
    ON y.product_id = t.product_id
WHERE y.price <> t.price;

-- NULL-safe alternative for PostgreSQL / Redshift-style systems:
-- WHERE y.price IS DISTINCT FROM t.price;


-- Task 2: New Products
SELECT
    t.product_id,
    t.product_name,
    t.price,
    t.status
FROM products_today t
WHERE NOT EXISTS (
    SELECT 1
    FROM products_yesterday y
    WHERE y.product_id = t.product_id
);


-- Task 3: Missing Products
SELECT
    y.product_id,
    y.product_name,
    y.price,
    y.status
FROM products_yesterday y
WHERE NOT EXISTS (
    SELECT 1
    FROM products_today t
    WHERE t.product_id = y.product_id
);


-- Task 4: Status Changes
SELECT
    t.product_id,
    t.product_name,
    y.status AS old_status,
    t.status AS new_status
FROM products_yesterday y
INNER JOIN products_today t
    ON y.product_id = t.product_id
WHERE y.status <> t.status;

-- NULL-safe alternative for PostgreSQL / Redshift-style systems:
-- WHERE y.status IS DISTINCT FROM t.status;
