import requests

url = f"/api/orders/ORD-1001"

def test_success():
    response = requests.get(url)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "PAID"
    print("API test passed!")