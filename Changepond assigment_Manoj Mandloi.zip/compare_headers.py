import pandas as pd
from pandas.errors import EmptyDataError
import argparse

def compare_csv(path1, path2):
    """
    Compare two CSV files and return the header differences.
    RUN:  python compare_headers.py "./csv_file.csv" "./csv_file2.csv"
    """
    try:
        df1 = pd.read_csv(path1, nrows=0, skipinitialspace=True)
        df2 = pd.read_csv(path2, nrows=0, skipinitialspace=True)
    except FileNotFoundError as e:
        raise ValueError(f"One or both CSV files not found.")
    except EmptyDataError as e:
        raise ValueError(f"One or both CSV files are empty.")
    
    headers1 = [col for col in df1.columns if col.strip() != col]
    headers2 = [col for col in df2.columns if col.strip() != col]

    # check for extra spaces in headers
    if len(headers1) > 0:
        print(f"{path1} files headers have extra spaces.")
    if len(headers2) > 0:
        print(f"{path2} files headers have extra spaces.")
    print(headers1)
    print(headers2)
    headers1 = [col.strip() for col in df1.columns]
    headers2 = [col.strip() for col in df2.columns]

    #check for exact match of headers
    if headers1 == headers2:
        print("Two files with identical headers.")
        return
    
    set1 = set(headers1)
    set2 = set(headers2)

    only_df1 = (set1 - set2) if set1 - set2 else {}
    only_df2 = (set2 - set1) if set2 - set1 else {}
    common = set1 & set2

    # check for only one column missing in either file
    if len(only_df1) == 1 and not only_df2:
        print(f"File {path1} has one header missing.")
    if len(only_df2) == 1 and not only_df1:
        print(f"File {path2} has one header missing.")
        

    common_order1 = [col for col in headers1 if col in common]
    common_order2 = [col for col in headers2 if col in common]

    same_order = common_order1 == common_order2

    print(f"Only in {path1}:", only_df1)
    print(f"Only in {path2}:", only_df2)
    print("Common headers:", common)
    print("Common headers in same relative order:", same_order)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Compare two CSV files")

    parser.add_argument("first_csv", help="Path to first CSV file")
    parser.add_argument("second_csv", help="Path to second CSV file")

    args = parser.parse_args()

    compare_csv(args.first_csv, args.second_csv)

