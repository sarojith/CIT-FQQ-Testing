1. Language used.
Python and library used is pandas

2. How to run the CSV comparison tool.
3. How to run the test
> Install Python (make sure python and scripts are in environment path for user)
> Open cmd and run "pip install pandas" then
> python compare_headers.py expected_orders.csv actual_orders.csv

4. SQL answers.
1. Why did you use INNER JOIN, LEFT JOIN, NOT EXISTS, or another approach?
In first and last query INNER JOIN part returns the common data set from both the tables so less overhead of filtering the data like in left join. also comparision of NULL could cause the issue but there are no NULLs in the dataset.

In the second and third i have used NOT IN as there are no NULL values (considering product_id as primary key) instead of NOT EXISTS which take care of NULLs.

2. What would change if product_id was not unique?
All queries will become ambiguous resulting in duplicate or incorrect dataset

3. What issue could happen if price or status can be NULL?
Then we need to add a check for NULL as well as != or = may fail when comparing price or status.

5. API test cases.
test1: Valid order id, input: ORD-1001, expected: 200, correct status in response, makes sure the endpoint works
test2: Invalid order id, input: ODR-1001, expected: 404, error message in response, make sure invalid order is handled
test3: No order id, input:"", expected: 400, error message in response, make sure missing order id is handled
test4: Schema validation, input: ORD-1001, expected: 200, correct status in response, contract is correctly validated
test5: Data type validation, input: ORD-1001, expected: 200, correct status in response, contract is correctly validated

6. Any assumptions you made.
None

7. AI usage statement.
I have used inline suggestion in VScode for correct syntex and method names.
I have used sqlite to check my queries




