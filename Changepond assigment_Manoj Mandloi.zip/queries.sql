SELECT
    pt.product_id,
    pt.product_name,
    py.price AS old_price,
    pt.price AS new_price
FROM product_today pt
INNER JOIN product_yesterday py
    ON py.product_id = pt.product_id
WHERE pt.price != py.price;
--------------------------------------

SELECT product_id, product_name, price, status
FROM product_today
where product_id not in (select product_id from product_yesterday);

--------------------------------------

SELECT product_id, product_name, price, status
FROM product_yesterday
where product_id not in (select product_id from product_today);

----------------------------------------

SELECT py.product_id, py.product_name, py.price, py.status
FROM product_yesterday py
INNER JOIN product_today pt
ON py.product_id = pt.product_id
WHERE py.price != pt.price;
--------------------------------------------



