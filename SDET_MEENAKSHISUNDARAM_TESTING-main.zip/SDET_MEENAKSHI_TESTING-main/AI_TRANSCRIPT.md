# AI Transcript 

## Tool Used
- Microsoft Copilot (VS Code integration)

## Prompts Entered
1. "Create a Node.js script to compare CSV headers between two files."
2. "Show me a Playwright API test that validates GET /api/orders/ORD-1001 returns 200 and status=PAID."
3. "Draft a README.md for this project with setup and AI usage statement."

## AI Responses Relied On
- Suggested Node.js code using `fs.readFileSync` and `split(',')` for header comparison.
- Drafted README.md sections with setup instructions and candidate acknowledgement.

## What I Accepted
- Playwright test example (kept structure, adjusted assertions).
- README.md outline (kept sections, removed curl commands).

## What I Changed
- Added error handling to CSV comparison script (missing file, empty file).
- Simplified README.md wording and aligned with exercise requirements.
- Verified Playwright test runs against my local Express server.

## Why Final Solution Works
- CSV comparison tool handles headers and error cases.
- Playwright test validates API endpoint response.
- README.md provides clear instructions and includes AI usage + candidate acknowledgement.

