const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

const orders = {
  'ORD-1001': { order_id: 'ORD-1001', status: 'PAID' },
};

app.get('/api/orders/:id', (req, res) => {
  const order = orders[req.params.id];
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

const server = app.listen(port, () => {
  console.log(`API server running at http://localhost:${port}`);
});

process.on('SIGINT', () => {
  server.close(() => process.exit(0));
});
process.on('SIGTERM', () => {
  server.close(() => process.exit(0));
});

process.on('SIGTERM', () => {
  server.close(() => process.exit(0));
});
