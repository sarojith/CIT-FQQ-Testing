//1. Price Changes
SELECT 
    t.product_id,
    t.product_name,
    y.price AS old_price,
    t.price AS new_price
FROM products_today t
INNER JOIN products_yesterday y 
    ON t.product_id = y.product_id
WHERE t.price <> y.price;


//2. New Products

SELECT 
    t.product_id,
    t.product_name,
    t.price,
    t.status
FROM products_today t
LEFT JOIN products_yesterday y 
    ON t.product_id = y.product_id
WHERE y.product_id IS NULL;


//3. Missing Products
SELECT 
    y.product_id,
    y.product_name,
    y.price,
    y.status
FROM products_yesterday y
LEFT JOIN products_today t 
    ON y.product_id = t.product_id
WHERE t.product_id IS NULL;


//4. Status Changes

SELECT 
    t.product_id,
    t.product_name,
    y.status AS old_status,
    t.status AS new_status
FROM products_today t
INNER JOIN products_yesterday y 
    ON t.product_id = y.product_id
WHERE t.status <> y.status;

//INNER JOIN: Used when comparing rows that exist in both tables (price/status changes).

//LEFT JOIN: Used to find missing or new products by checking for NULL matches.

//Non-unique product_id: Would require handling duplicates (e.g., using DISTINCT, grouping, or surrogate keys).

//NULL values: Comparisons (<>) may fail; need IS DISTINCT FROM or explicit IS NULL checks.