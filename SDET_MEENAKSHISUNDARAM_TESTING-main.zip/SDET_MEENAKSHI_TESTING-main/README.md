# SDET Candidate Exercise — API, SQL, CSV

## 📌 Language Used
- JavaScript (Node.js)
- Playwright for API testing
- Express.js for simple API server
- Basic SQL queries

---

## ⚙️ Project Setup

1. Initialize Node.js project:
   ```bash
   npm init -y


2. Install dependencies:
npm install @playwright/test express

3. Project structure:
SDET_MEENAKSHI_TESTING/
├── playwright.config.js
├── server.js
├── answers.sql
├── AI_TRANSCRIPT.md
└── tests/
    ├── API-Pseudo.spec.js
    ├── compareHeaders.js
    ├── compareHeaders.test.js
    ├── compareHeaders.error.test.js
    ├── expected_orders.csv
    └── actual_orders.csv

🔧 Configuration
playwright.config.js:

module.exports = {
  use: {
    baseURL: 'http://localhost:3000',
  },
  testDir: './tests',
};

🖥️ API Server
server.js:

const express = require('express');
const app = express();
const port = 3000;

app.get('/api/orders/ORD-1001', (req, res) => {
  res.json({
    order_id: "ORD-1001",
    status: "PAID"
  });
});

app.listen(port, () => {
  console.log(`API server running at http://localhost:${port}`);
});

Start the server:
node server.js

🧪 Test Files
API Test — tests/API-Pseudo.spec.js
Run directly (no cd tests needed):

npx playwright test tests/API-Pseudo.spec.js


CSV Comparison Tool — compareHeaders.js
Navigate into tests first:

cd tests
node compareHeaders.js expected_orders.csv actual_orders.csv

CSV Comparison Tests — compareHeaders.test.js
cd tests
node compareHeaders.test.js

Error Handling Tests — compareHeaders.error.test.js

cd tests
node compareHeaders.error.test.js

▶️ Running the Playwright Report

npx playwright show-report









## Part C — API Task 1: Test Case Design

### Positive Test Cases

| **Test Case ID** | **Scenario** | **Testing Steps** | **Expected Result** |
|------------------|--------------|-------------------|----------------------|
| TC_API_001 | Valid Order Retrieval | 1. Send `GET /api/orders/ORD-1001` <br> 2. Observe HTTP response | HTTP 200 OK <br> JSON body contains all fields (`order_id`, `customer_id`, `amount`, `currency`, `status`, `created_at`) <br> `status = PAID` |
| TC_API_002 | Valid Order with Different Status | 1. Send `GET /api/orders/ORD-1002` <br> 2. Observe HTTP response | HTTP 200 OK <br> JSON body contains all fields <br> `status = PENDING` |
| TC_API_003 | Schema Validation | 1. Send `GET /api/orders/ORD-1001` <br> 2. Validate JSON schema | `amount` is numeric <br> `currency` is GBP/USD/EUR <br> `created_at` is ISO timestamp |

### Negative Test Cases

| **Test Case ID** | **Scenario** | **Testing Steps** | **Expected Result** |
|------------------|--------------|-------------------|----------------------|
| TC_API_004 | Non-existent Order | 1. Send `GET /api/orders/ORD-9999` | HTTP 404 Not Found <br> JSON error message: `"Order not found"` |
| TC_API_005 | Invalid Order ID Format | 1. Send `GET /api/orders/123` | HTTP 400 Bad Request <br> JSON error message: `"Invalid order ID format"` |
| TC_API_006 | Unauthorized Access | 1. Send `GET /api/orders/ORD-1001` without authentication token | HTTP 401 Unauthorized <br> JSON error message: `"Authentication required"` |
| TC_API_007 | Invalid Currency Value | 1. Send `GET /api/orders/ORD-1001` <br> 2. Validate `currency` field | HTTP 200 OK <br> Test fails if `currency` not GBP/USD/EUR |
| TC_API_008 | Server Error Simulation | 1. Simulate DB outage <br> 2. Send `GET /api/orders/ORD-1001` | HTTP 500 Internal Server Error <br> JSON error message: `"Internal server error"` |

---

### Notes
- **Scenario**: Describes what is being tested.  
- **Testing Steps**: Step-by-step instructions to execute the test.  
- **Expected Result**: What the API should return if working correctly.  
- **Actual Result**: To be filled in after execution (Pass/Fail + details).  

# Part A — SQL Exercise

## 📂 Files
- `answers.sql` → Contains SQL queries for product comparison between `products_today` and `products_yesterday`.

---

## ⚙️ Prerequisites
- Install a relational database (e.g., **PostgreSQL**, **MySQL**, or **SQLite**).
- Ensure you have a SQL client or command-line tool to run queries.
- Create two tables: `products_today` and `products_yesterday`.
- Load product data into these tables (from CSV or manual inserts).

Example (PostgreSQL):
```sql
CREATE TABLE products_today (
  product_id INT,
  product_name VARCHAR(100),
  price DECIMAL(10,2),
  status VARCHAR(20)
);

CREATE TABLE products_yesterday (
  product_id INT,
  product_name VARCHAR(100),
  price DECIMAL(10,2),
  status VARCHAR(20)
);


Running the SQL Queries
Open your SQL client or terminal.

Connect to your database.

Run the queries in answers.sql

1. Price Changes

SELECT 
    t.product_id,
    t.product_name,
    y.price AS old_price,
    t.price AS new_price
FROM products_today t
INNER JOIN products_yesterday y 
    ON t.product_id = y.product_id
WHERE t.price <> y.price;


Purpose: Finds products whose price changed compared to yesterday.

2. New Products

SELECT 
    t.product_id,
    t.product_name,
    t.price,
    t.status
FROM products_today t
LEFT JOIN products_yesterday y 
    ON t.product_id = y.product_id
WHERE y.product_id IS NULL;

Purpose: Identifies products that exist today but not yesterday.

3. Missing Products

SELECT 
    y.product_id,
    y.product_name,
    y.price,
    y.status
FROM products_yesterday y
LEFT JOIN products_today t 
    ON y.product_id = t.product_id
WHERE t.product_id IS NULL;

Purpose: Finds products that were present yesterday but missing today.

4. Status Changes

SELECT 
    t.product_id,
    t.product_name,
    y.status AS old_status,
    t.status AS new_status
FROM products_today t
INNER JOIN products_yesterday y 
    ON t.product_id = y.product_id
WHERE t.status <> y.status;

Purpose: Detects products whose status changed (e.g., ACTIVE → INACTIVE).

INNER JOIN → Used when comparing rows that exist in both tables (price/status changes).

LEFT JOIN → Used to find missing or new products by checking for NULL matches.

Non-unique product_id → Would require handling duplicates (e.g., using DISTINCT, grouping, or surrogate keys).

NULL values → Comparisons with <> may fail; use IS DISTINCT FROM or explicit IS NULL checks if needed.

Expected Output

Price Changes → List of products with old vs new prices.

New Products → Products that appeared today but not yesterday.

Missing Products → Products that disappeared today.

Status Changes → Products with old vs new status.


# API Testing with Playwright

## 📌 Overview
This project demonstrates a basic automated API test using **Playwright Test**.  
The test validates that:

- `GET /api/orders/ORD-1001` returns **HTTP 200**
- The JSON response contains:
  - `order_id = ORD-1001`
  - `status = PAID`

---

## ⚙️ Project Setup

1. **Initialize Node.js project**
   ```bash
   npm init -y

2. Install dependencies
npm install @playwright/test express
📂 Project Structure

api-order-status/
├── playwright.config.js
├── server.js
└── tests/
    └── api-pseudo.spec.js

🔧 Configuration — playwright.config.js
// playwright.config.js
module.exports = {
  use: {
    baseURL: 'http://localhost:3000', // API server base URL
  },
  testDir: './tests',
};

🖥️ API Server — server.js
const express = require('express');
const app = express();
const port = 3000;

app.get('/api/orders/ORD-1001', (req, res) => {
  res.json({
    order_id: "ORD-1001",
    status: "PAID"
  });
});

app.listen(port, () => {
  console.log(`API server running at http://localhost:${port}`);
});
🧪 Test File — tests/api-pseudo.spec.js

const { test, expect } = require('@playwright/test');

test.describe('API Order Status Tests', () => {
  
  test('GET /api/orders/ORD-1001 returns 200 and status=PAID', async ({ request }) => {
    // Send GET request
    const response = await request.get('/api/orders/ORD-1001');

    // Validate HTTP status
    expect(response.status()).toBe(200);

    // Parse JSON body
    const body = await response.json();

    // Validate fields
    expect(body.order_id).toBe("ORD-1001");
    expect(body.status).toBe("PAID");
  });

});

▶️ Running the Project
1.Start the API server:
node server.js
2.Run the Playwright test:
npx playwright test tests/api-pseudo.spec.js

3.View the HTML report:
npx playwright show-report


By submitting this exercise, I confirm that:

I have followed the AI usage rules.

If I used AI, I have included the full relevant AI transcript or equivalent usage record.

I understand the submitted solution.

I am able to explain, modify, and debug the solution during the interview.

I understand that failure to disclose AI use, or inability to explain the submitted work, may result in rejection.







