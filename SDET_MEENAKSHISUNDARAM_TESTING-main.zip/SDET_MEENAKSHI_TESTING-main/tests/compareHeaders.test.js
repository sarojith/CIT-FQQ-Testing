const assert = require("assert");
const fs = require("fs");
const { execSync } = require("child_process");

function runTool(file1, file2) {
  return execSync(`node compareHeaders.js ${file1} ${file2}`).toString();
}

// Test 1: Identical headers
fs.writeFileSync("file1.csv", "a,b,c\n1,2,3");
fs.writeFileSync("file2.csv", "a,b,c\n4,5,6");
let output = runTool("file1.csv", "file2.csv");
assert(output.includes("Common headers:\na\nb\nc"));
assert(output.includes("Only in file1.csv:\nNone"));

// Test 2: Missing header
fs.writeFileSync("file3.csv", "a,b\n1,2");
fs.writeFileSync("file4.csv", "a,b,c\n3,4,5");
output = runTool("file3.csv", "file4.csv");
assert(output.includes("Only in file3.csv:\nNone"));
assert(output.includes("Only in file4.csv:\nc"));

// Test 3: Extra spaces
fs.writeFileSync("file5.csv", " a , b , c \n");
fs.writeFileSync("file6.csv", "a,b,c\n");
output = runTool("file5.csv", "file6.csv");
assert(output.includes("Common headers:\na\nb\nc"));

console.log("All tests passed!");
