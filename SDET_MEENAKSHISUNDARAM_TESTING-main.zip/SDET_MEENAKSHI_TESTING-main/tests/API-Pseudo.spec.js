const { test, expect } = require('@playwright/test');

test('GET /api/orders/ORD-1001 returns 200 and status=PAID', async ({ request }) => {
  // Send GET request (baseURL is automatically prepended)
  const response = await request.get('/api/orders/ORD-1001');

  // Validate HTTP status
  expect(response.status()).toBe(200);

  // Parse JSON body
  const body = await response.json();

  // Validate fields
  expect(body.order_id).toBe("ORD-1001");
  expect(body.status).toBe("PAID");

 
});
