const assert = require("assert");
const fs = require("fs");
const { execSync } = require("child_process");

function runTool(args) {
  try {
    return execSync(`node compareHeaders.js ${args}`, { encoding: "utf8" });
  } catch (err) {
    return (err.stdout || "") + (err.stderr || "");
  }
}

// Test 1: Missing arguments
let output = runTool("");
assert(
  output.includes("Usage: node compareHeaders.js"),
  `Expected usage message, got:\n${output}`
);

// Test 2: File not found
output = runTool("expected_orders.csv missing.csv");
assert(
  output.includes("File not found"),
  `Expected file not found error, got:\n${output}`
);

// Test 3: Empty file
fs.writeFileSync("empty.csv", "");
output = runTool("expected_orders.csv empty.csv");
assert(
  output.includes("File is empty"),
  `Expected empty file error, got:\n${output}`
);

// Test 4: Invalid headers (only commas/spaces)
fs.writeFileSync("bad.csv", ",,,");
output = runTool("expected_orders.csv bad.csv");
assert(
  output.includes("No valid headers"),
  `Expected invalid headers error, got:\n${output}`
);

console.log("✅ Error handling tests passed!");
