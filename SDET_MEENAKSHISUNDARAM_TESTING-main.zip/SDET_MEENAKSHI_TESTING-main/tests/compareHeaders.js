
const fs = require("fs");

function readHeaders(filePath) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`File not found: ${filePath}`);
  }
  const data = fs.readFileSync(filePath, "utf8").trim();
  if (!data) throw new Error(`File is empty: ${filePath}`);
  const firstLine = data.split(/\r?\n/)[0];
  const headers = firstLine.split(",").map(h => h.trim()).filter(Boolean);
  if (headers.length === 0) throw new Error(`No valid headers in: ${filePath}`);
  return headers;
}

function compareHeaders(expectedFile, actualFile) {
  const expectedHeaders = readHeaders(expectedFile);
  const actualHeaders = readHeaders(actualFile);

  const onlyInExpected = expectedHeaders.filter(h => !actualHeaders.includes(h));
  const onlyInActual = actualHeaders.filter(h => !expectedHeaders.includes(h));
  const commonHeaders = expectedHeaders.filter(h => actualHeaders.includes(h));

  const expectedOrder = expectedHeaders.filter(h => commonHeaders.includes(h));
  const actualOrder = actualHeaders.filter(h => commonHeaders.includes(h));
  const sameOrder = expectedOrder.join(",") === actualOrder.join(",");

  console.log(`Only in ${expectedFile}:\n${onlyInExpected.join("\n") || "None"}`);
  console.log(`\nOnly in ${actualFile}:\n${onlyInActual.join("\n") || "None"}`);
  console.log(`\nCommon headers:\n${commonHeaders.join("\n") || "None"}`);
  console.log(`\nCommon headers in same relative order:\n${sameOrder}`);
}

// CLI
if (process.argv.length < 4) {
  console.error("Usage: node compareHeaders.js <expected.csv> <actual.csv>");
  process.exit(1);
}

try {
  compareHeaders(process.argv[2], process.argv[3]);
} catch (err) {
  console.error("Error:", err.message);
  process.exit(1);
}
