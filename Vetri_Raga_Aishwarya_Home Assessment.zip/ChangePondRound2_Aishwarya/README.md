CSV Header Comparison & SQL/API Assessment
1. Language Used
•	JavaScript (Node.js) - CSV comparison tool and automated tests
•	SQL - Database query solutions
•	Markdown - Documentation
________________________________________
2. How to Run the CSV Comparison Tool
Prerequisites
•	Node.js v16 or later
Execute
node compareHeaders.js expected.csv actual.csv
Example
node compareHeaders.js expected.csv actual.csv
The tool performs the following:
•	Reads only the first row (headers) from each CSV file.
•	Trims whitespace around each header.
•	Identifies:
o	Headers only in the expected file
o	Headers only in the actual file
o	Common headers
o	Whether common headers appear in the same relative order
The tool also handles:
•	Missing command-line arguments
•	File not found
•	Empty CSV files
•	Invalid/empty header rows
________________________________________
3. How to Run the Tests
Execute:
node headerComparisonTests.js
The automated tests cover:
•	Identical headers
•	Missing headers
•	Extra headers
•	Leading/trailing whitespace
•	Windows (CRLF) line endings
•	Header order differences
•	Completely different headers
•	Empty CSV
•	Duplicate headers
•	Case sensitivity
•	Error handling scenarios
________________________________________
4. SQL Answers
Task 1 — Price Changes
Uses an INNER JOIN to compare matching products and identify price differences.
Task 2 — New Products
Uses LEFT JOIN (or NOT EXISTS) to find products present today but absent yesterday.
Task 3 — Missing Products
Uses LEFT JOIN (or NOT EXISTS) to identify products that existed yesterday but are missing today.
Task 4 — Status Changes
Uses an INNER JOIN to compare product statuses between the two tables.
Explanation
•	INNER JOIN
o	Used when comparing records that exist in both tables.
o	Ideal for price and status change detection.
•	LEFT JOIN
o	Used to identify missing or newly added records.
•	NOT EXISTS
o	Efficient alternative for detecting unmatched rows.
Assumptions
•	product_id is unique.
•	product_id is the primary key.
•	Products are compared only using product_id.
•	Tables represent two consecutive snapshots.
If product_id is not unique
Duplicate records can produce multiple join matches and incorrect results. A unique or composite key should be used.
If price or status contains NULL
Standard comparisons (<>) do not treat NULL values as equal or unequal. Use NULL-safe comparisons such as:
•	IS DISTINCT FROM (PostgreSQL)
•	<=> (MySQL)
•	COALESCE() where appropriate
________________________________________
5. API Test Cases
The API testing covers both positive and negative scenarios.
Functional Tests
•	Valid order retrieval (200 OK)
•	Invalid Order ID (400 Bad Request)
•	Unauthorized request (401 Unauthorized)
•	Forbidden request (403 Forbidden)
•	Order not found (404 Not Found)
•	Unsupported HTTP method (405 Method Not Allowed)
•	Unsupported media type (415 Unsupported Media Type)
•	Rate limiting (429 Too Many Requests)
Redirection Tests
•	301 Moved Permanently
•	302 Found
•	303 See Other
•	307 Temporary Redirect
•	308 Permanent Redirect
Server Error Tests
•	500 Internal Server Error
•	501 Not Implemented
•	502 Bad Gateway
•	503 Service Unavailable
•	504 Gateway Timeout
•	505 HTTP Version Not Supported
•	507 Insufficient Storage
Additional Validation
•	Response schema validation
•	Data type validation
•	Response header validation
•	Authentication & authorization
•	SQL Injection protection
•	XSS validation
•	Path traversal testing
•	Performance and response time
•	Concurrency testing
•	Load and stress testing
•	Idempotency validation
•	Gateway and proxy failure scenarios
________________________________________
6. Assumptions Made
CSV Tool
•	First row always represents headers.
•	CSV files are comma-separated.
•	Header comparison is case-sensitive.
•	Only header rows are compared.
•	Header order validation considers only common headers.
SQL
•	product_id uniquely identifies a product.
•	Data snapshots represent yesterday and today.
•	Tables have identical schema.
API
•	Authentication is required unless specified otherwise.
•	API follows REST principles.
•	JSON is the default response format.
•	Standard HTTP status codes are used.
________________________________________
7. AI Usage Statement
This solution was developed with assistance from generative AI (ChatGPT) for brainstorming, implementation guidance, documentation, and review. All generated code, SQL queries, API test scenarios, and documentation were manually reviewed, validated, and refined before final submission.
