Conversation Transcript
User
Act as a Expert in SQL and answer me the queries for the below table
structure products_yesterday and products_today both have the same table
structure
    product_id
    product_name
    price
    status

I have below questions
SQL Task 1 --- Price Changes
Write a SQL query to find products whose price changed from yesterday to
today.
Expected output columns: - product_id - product_name - old_price -
new_price
---
SQL Task 2 --- New Products
Write a SQL query to find products that are new today, meaning they
exist in products_today but not in products_yesterday.
Expected output columns: - product_id - product_name - price - status
---
SQL Task 3 --- Missing Products
Write a SQL query to find products that existed yesterday but are
missing today.
Expected output columns: - product_id - product_name - price - status
---
SQL Task 4 --- Status Changes
Write a SQL query to find products whose status changed from yesterday
to today.
Expected output columns: - product_id - product_name - old_status -
new_status
---
SQL Task 5 --- Short Explanation
In your README, briefly explain:
Why did you use INNER JOIN, LEFT JOIN, NOT EXISTS, or another
approach?
What would change if product_id was not unique?
What issue could happen if price or status can be NULL?
---
Assistant
SQL Task 1 --- Price Changes
``` sql
SELECT
    y.product_id,
    y.product_name,
    y.price AS old_price,
    t.price AS new_price
FROM products_yesterday y
INNER JOIN products_today t
    ON y.product_id = t.product_id
WHERE y.price <> t.price;
```
SQL Task 2 --- New Products
``` sql
SELECT
    t.product_id,
    t.product_name,
    t.price,
    t.status
FROM products_today t
LEFT JOIN products_yesterday y
    ON t.product_id = y.product_id
WHERE y.product_id IS NULL;
```
Alternative:
``` sql
SELECT
    t.product_id,
    t.product_name,
    t.price,
    t.status
FROM products_today t
WHERE NOT EXISTS (
    SELECT 1
    FROM products_yesterday y
    WHERE y.product_id = t.product_id
);
```
SQL Task 3 --- Missing Products
``` sql
SELECT
    y.product_id,
    y.product_name,
    y.price,
    y.status
FROM products_yesterday y
LEFT JOIN products_today t
    ON y.product_id = t.product_id
WHERE t.product_id IS NULL;
```
Alternative:
``` sql
SELECT
    y.product_id,
    y.product_name,
    y.price,
    y.status
FROM products_yesterday y
WHERE NOT EXISTS (
    SELECT 1
    FROM products_today t
    WHERE t.product_id = y.product_id
);
```
SQL Task 4 --- Status Changes
``` sql
SELECT
    y.product_id,
    y.product_name,
    y.status AS old_status,
    t.status AS new_status
FROM products_yesterday y
INNER JOIN products_today t
    ON y.product_id = t.product_id
WHERE y.status <> t.status;
```
README Explanation
INNER JOIN is used to compare records that exist in both tables
(price/status changes).
LEFT JOIN identifies records missing from one table.
NOT EXISTS is an efficient alternative for finding unmatched
records.
If `product_id` is not unique, joins can create duplicate
matches, so a unique or composite key is recommended.
If `price` or `status` can be NULL, standard `<>` comparisons
may miss changes. Use `IS DISTINCT FROM`, MySQL's `<=>`, or
`COALESCE` for NULL-safe comparisons.
Interview Summary
Use `INNER JOIN` for comparing common products.
Use `LEFT JOIN` or `NOT EXISTS` for new and missing products.
Ensure `product_id` is unique.
Handle NULL values using NULL-safe comparison techniques.