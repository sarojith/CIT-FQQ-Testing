 assert = require("assert");

/**
 * Compare two header arrays
 */
function compareHeaders(expectedHeaders, actualHeaders) {

    // Trim whitespace
    expectedHeaders = expectedHeaders.map(h => h.trim());
    actualHeaders = actualHeaders.map(h => h.trim());

    const expectedSet = new Set(expectedHeaders);
    const actualSet = new Set(actualHeaders);

    const onlyExpected = expectedHeaders.filter(h => !actualSet.has(h));
    const onlyActual = actualHeaders.filter(h => !expectedSet.has(h));
    const commonHeaders = expectedHeaders.filter(h => actualSet.has(h));

    // Check relative order
    let lastIndex = -1;
    let sameOrder = true;

    for (const header of commonHeaders) {
        const currentIndex = actualHeaders.indexOf(header);

        if (currentIndex < lastIndex) {
            sameOrder = false;
            break;
        }

        lastIndex = currentIndex;
    }

    return {
        onlyExpected,
        onlyActual,
        commonHeaders,
        sameOrder
    };
}

/**
 * Execute a test case
 */
function runTest(
    testName,
    expectedHeaders,
    actualHeaders,
    expectedOnlyExpected,
    expectedOnlyActual,
    expectedCommon,
    expectedOrder
) {

    const result = compareHeaders(expectedHeaders, actualHeaders);

    assert.deepStrictEqual(result.onlyExpected, expectedOnlyExpected);
    assert.deepStrictEqual(result.onlyActual, expectedOnlyActual);
    assert.deepStrictEqual(result.commonHeaders, expectedCommon);
    assert.strictEqual(result.sameOrder, expectedOrder);

    console.log(`✅ ${testName} Passed`);
}

console.log("\nRunning Header Comparison Tests...\n");

/*--------------------------------------------------*/
/* Test 1 : Identical Headers */
/*--------------------------------------------------*/
runTest(
    "Test 1 - Identical Headers",
    ["id", "name", "email", "age"],
    ["id", "name", "email", "age"],
    [],
    [],
    ["id", "name", "email", "age"],
    true
);

/*--------------------------------------------------*/
/* Test 2 : Missing Header */
/*--------------------------------------------------*/
runTest(
    "Test 2 - Missing Header",
    ["id", "name", "email", "age"],
    ["id", "name", "email"],
    ["age"],
    [],
    ["id", "name", "email"],
    true
);

/*--------------------------------------------------*/
/* Test 3 : Extra Spaces */
/*--------------------------------------------------*/
runTest(
    "Test 3 - Extra Spaces",
    ["id", " name ", " email ", " age "],
    ["id", "name", "email", "age"],
    [],
    [],
    ["id", "name", "email", "age"],
    true
);

/*--------------------------------------------------*/
/* Test 4 : Windows Line Endings */
/*--------------------------------------------------*/

const windowsExpected =
    "id,name,email,age\r\n1,John,abc@test.com,25"
        .split(/\r?\n/)[0]
        .split(",");

const windowsActual =
    "id,name,email,age\r\n2,Alice,xyz@test.com,30"
        .split(/\r?\n/)[0]
        .split(",");

runTest(
    "Test 4 - Windows Line Endings",
    windowsExpected,
    windowsActual,
    [],
    [],
    ["id", "name", "email", "age"],
    true
);

/*--------------------------------------------------*/
/* Test 5 : Different Header Order */
/*--------------------------------------------------*/
runTest(
    "Test 5 - Different Order",
    ["id", "name", "email", "age"],
    ["id", "email", "name", "age"],
    [],
    [],
    ["id", "name", "email", "age"],
    false
);

/*--------------------------------------------------*/
/* Test 6 : Extra Header in Actual */
/*--------------------------------------------------*/
runTest(
    "Test 6 - Extra Header",
    ["id", "name", "email"],
    ["id", "name", "email", "phone"],
    [],
    ["phone"],
    ["id", "name", "email"],
    true
);

/*--------------------------------------------------*/
/* Test 7 : Completely Different */
/*--------------------------------------------------*/
runTest(
    "Test 7 - Different Headers",
    ["id", "name", "email"],
    ["product", "price", "quantity"],
    ["id", "name", "email"],
    ["product", "price", "quantity"],
    [],
    true
);

/*--------------------------------------------------*/
/* Test 8 : Empty Expected */
/*--------------------------------------------------*/
runTest(
    "Test 8 - Empty Expected",
    [],
    ["id", "name", "email"],
    [],
    ["id", "name", "email"],
    [],
    true
);

/*--------------------------------------------------*/
/* Test 9 : Duplicate Headers */
/*--------------------------------------------------*/
runTest(
    "Test 9 - Duplicate Headers",
    ["id", "name", "name", "email"],
    ["id", "name", "email"],
    [],
    [],
    ["id", "name", "name", "email"],
    true
);

/*--------------------------------------------------*/
/* Test 10 : Case Sensitivity */
/*--------------------------------------------------*/
runTest(
    "Test 10 - Case Sensitive",
    ["ID", "Name", "Email"],
    ["id", "name", "email"],
    ["ID", "Name", "Email"],
    ["id", "name", "email"],
    [],
    true
);

console.log("\n🎉 All Tests Passed Successfully!");