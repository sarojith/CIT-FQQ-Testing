const fs = require("fs");

/**
 * Reads and validates CSV headers
 */
function getHeaders(filePath) {

    // 1. Check if file exists
    if (!fs.existsSync(filePath)) {
        throw new Error(`File not found: ${filePath}`);
    }

    // Read file
    const fileContent = fs.readFileSync(filePath, "utf8");

    // 2. Check for empty file
    if (!fileContent.trim()) {
        throw new Error(`CSV file is empty: ${filePath}`);
    }

    // Read first line only
    const firstLine = fileContent.split(/\r?\n/)[0];

    // Split headers and trim spaces
    const headers = firstLine
        .split(",")
        .map(header => header.trim())
        .filter(header => header.length > 0);

    // 3. Check if header row has valid headers
    if (headers.length === 0) {
        throw new Error(`Header row contains no valid headers: ${filePath}`);
    }

    return headers;
}

/**
 * Check whether common headers
 * appear in the same relative order
 */
function isSameRelativeOrder(actualHeaders, commonHeaders) {

    let lastIndex = -1;

    for (const header of commonHeaders) {

        const currentIndex = actualHeaders.indexOf(header);

        if (currentIndex < lastIndex) {
            return false;
        }

        lastIndex = currentIndex;
    }

    return true;
}

/**
 * Main Program
 */
function main() {

    // 4. Check command-line arguments
    const [, , expectedFile, actualFile] = process.argv;

    if (!expectedFile || !actualFile) {
        console.error("Error: Missing file path(s).");
        console.log("Usage:");
        console.log("node compareHeaders.js expected.csv actual.csv");
        process.exit(1);
    }

    try {

        const expectedHeaders = getHeaders(expectedFile);
        const actualHeaders = getHeaders(actualFile);

        const expectedSet = new Set(expectedHeaders);
        const actualSet = new Set(actualHeaders);

        const onlyExpected = expectedHeaders.filter(
            header => !actualSet.has(header)
        );

        const onlyActual = actualHeaders.filter(
            header => !expectedSet.has(header)
        );

        const commonHeaders = expectedHeaders.filter(
            header => actualSet.has(header)
        );

        const sameOrder = isSameRelativeOrder(
            actualHeaders,
            commonHeaders
        );

        console.log(`Only in ${expectedFile}:`);
        console.log(onlyExpected.length ? onlyExpected.join("\n") : "None");

        console.log("\n--------------------------");

        console.log(`Only in ${actualFile}:`);
        console.log(onlyActual.length ? onlyActual.join("\n") : "None");

        console.log("\n--------------------------");

        console.log("Common Headers:");
        console.log(commonHeaders.length ? commonHeaders.join("\n") : "None");

        console.log("\n--------------------------");

        console.log(`Common headers in same relative order: ${sameOrder}`);

    } catch (error) {

        console.error(`Error: ${error.message}`);
        process.exit(1);

    }
}

// Run program
main();