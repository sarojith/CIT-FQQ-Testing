API Testing Conversation Export
User
Act as API expert and Assume there is an endpoint:
`GET /api/orders/{order_id}`
Example successful response:
``` json
{
  "order_id": "ORD-1001",
  "customer_id": "C001",
  "amount": 100.50,
  "currency": "GBP",
  "status": "PAID",
  "created_at": "2026-05-20T10:30:00Z"
}
```
API Task 1
Write 5 automated test cases including: 1. Test name 2. Input 3.
Expected result 4. Why useful
API Task 2
Write pseudo-code or real code validating:
`GET /api/orders/ORD-1001`
returns HTTP 200 and status = PAID using any framework.
---
Assistant
API Task 1 -- Test Cases
---
Test           Input                  Expected Result                   Why
---
Valid order    GET                    200 OK with correct order details Happy path
retrieval      /api/orders/ORD-1001                                     validation
Non-existing   GET                    404 Not Found                     Resource
order          /api/orders/ORD-9999                                     validation
Invalid order  GET /api/orders/@@@123 400 Bad Request                   Input
ID                                                                      validation
Unauthorized   Missing auth           401 Unauthorized                  Security
request                                                                 validation
Response       Valid GET              Correct field names and data      API contract
schema                                types                             validation
validation
API Task 2 -- Playwright Example
``` ts
import { test, expect } from '@playwright/test';

test('Verify GET Order API returns PAID order', async ({ request }) => {
  const response = await request.get('/api/orders/ORD-1001');
  expect(response.status()).toBe(200);

  const body = await response.json();
  expect(body.order_id).toBe('ORD-1001');
  expect(body.status).toBe('PAID');
});
```
Additional examples were also provided for: - Rest Assured (Java) -
Python requests - Postman Tests
An interview explanation describing the overall API testing strategy was
also included.
---
User
Include comprehensive API test scenarios covering: - 5xx server errors -
Gateway/proxy errors - 3xx redirection - Other HTTP status codes - Edge
cases
Explain: - Meaning of each status code - When it occurs - Expected API
behavior - Corresponding test cases
---
Assistant
Provided a comprehensive API test suite including:
Functional Tests
200 OK
400 Bad Request
401 Unauthorized
403 Forbidden
404 Not Found
405 Method Not Allowed
406 Not Acceptable
409 Conflict
410 Gone
413 Payload Too Large
414 URI Too Long
415 Unsupported Media Type
429 Too Many Requests
Redirection (3xx)
301 Moved Permanently
302 Found
303 See Other
304 Not Modified
307 Temporary Redirect
308 Permanent Redirect
Server Errors (5xx)
500 Internal Server Error
501 Not Implemented
502 Bad Gateway
503 Service Unavailable
504 Gateway Timeout
505 HTTP Version Not Supported
507 Insufficient Storage
Additional Categories
Gateway/Proxy testing
Security testing (SQL Injection, XSS, Path Traversal)
Performance testing (Load, Stress, Soak, Concurrency)
Response schema validation
Header validation
Data type validation
Response time validation
Idempotency validation
A summary table explained every HTTP status code, its meaning, when it
occurs, and the expected API behavior.