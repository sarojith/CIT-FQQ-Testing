package SDETAssessment;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class CompareHeaders {
	
	

	    public static void main(String[] args) {
	        // Requirement 7: Handle missing file path arguments
	        if (args.length < 2) {
	            System.out.println("Error: Please provide two CSV file paths as command-line arguments.");
	            System.out.println("Usage: java CsvHeaderComparer <expected_file.csv> <actual_file.csv>");
	            return;
	        }

	        String expectedPath = args[0];
	        String actualPath = args[1];

	        try {
	            // Process the files and run the comparison
	            compareCsvHeaders(expectedPath, actualPath);
	        } catch (IOException e) {
	            System.out.println("An error occurred while reading the files: " + e.getMessage());
	        }
	    }

	    public static void compareCsvHeaders(String expectedPath, String actualPath) throws IOException {
	        // Requirement 2 & 7: Read headers and handle non-existent/empty files
	        List<String> expectedHeaders = readHeader(expectedPath);
	        List<String> actualHeaders = readHeader(actualPath);

	        if (expectedHeaders == null) {
	            System.out.println("Error: Expected file is empty or could not be read.");
	            return;
	        }
	        if (actualHeaders == null) {
	            System.out.println("Error: Actual file is empty or could not be read.");
	            return;
	        }

	        // Requirement 6: Find headers only in the expected file
	        List<String> onlyInExpected = new ArrayList<>();
	        for (String header : expectedHeaders) {
	            if (!actualHeaders.contains(header)) {
	                onlyInExpected.add(header);
	            }
	        }

	        // Requirement 6: Find headers only in the actual file
	        List<String> onlyInActual = new ArrayList<>();
	        for (String header : actualHeaders) {
	            if (!expectedHeaders.contains(header)) {
	                onlyInActual.add(header);
	            }
	        }

	        // Requirement 6: Find headers present in both files
	        List<String> commonHeaders = new ArrayList<>();
	        for (String header : expectedHeaders) {
	            if (actualHeaders.contains(header)) {
	                commonHeaders.add(header);
	            }
	        }

	        // Requirement 6: Check if common headers appear in the same relative order
	        boolean sameOrder = true;
	        int lastIndex = -1;
	        for (String header : commonHeaders) {
	            int currentIndex = actualHeaders.indexOf(header);
	            if (currentIndex < lastIndex) {
	                sameOrder = false;
	                break;
	            }
	            lastIndex = currentIndex;
	        }

	        // Print results
	        System.out.println("--- CSV Header Comparison Results ---");
	        System.out.println("Headers only in expected file: " + onlyInExpected);
	        System.out.println("Headers only in actual file: " + onlyInActual);
	        System.out.println("Headers present in both files: " + commonHeaders);
	        System.out.println("Common headers in same relative order? " + (sameOrder ? "Yes" : "No"));
	    }

	    // Helper method to read, split, and trim the first line of a CSV file
	    private static List<String> readHeader(String filePath) throws IOException {
	        File file = new File(filePath);
	        
	        // Requirement 7: Handle file does not exist
	        if (!file.exists()) {
	            System.out.println("Error: File not found at " + filePath);
	            return null;
	        }

	        // Requirement 2: Read only the first line using BufferedReader
	        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
	            String firstLine = br.readLine();
	            
	            // Requirement 7: Handle empty CSV file
	            if (firstLine == null || firstLine.trim().isEmpty()) {
	                return null;
	            }

	            // Requirement 3: Split headers using a comma
	            String[] rawHeaders = firstLine.split(",");
	            List<String> cleanedHeaders = new ArrayList<>();

	            // Requirement 4: Trim whitespace around each header
	            for (String header : rawHeaders) {
	                cleanedHeaders.add(header.trim());
	            }

	            return cleanedHeaders;
	        }
	    }
	}


