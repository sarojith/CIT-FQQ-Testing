GET /api/orders/{order_id}
Example successful response:
{
  "order_id": "ORD-1001",
  "customer_id": "C001",
  "amount": 100.50,
  "currency": "GBP",
  "status": "PAID",
  "created_at": "2026-05-20T10:30:00Z"
}

Test Case 1

Test Name: Verify valid order details

Input:GET /api/orders/ORD-1001

Expected Result:
HTTP Status Code = 200
order_id = ORD-1001
status = PAID

Ensures that a valid order ID returns the correct order details successfully.

Test Case 2

Test Name: Verify invalid order ID

Input:GET /api/orders/ORD-9999

Expected Result:
HTTP Status Code = 404
Error message: Order not found

Verifies that the API handles invalid order IDs correctly

Test Case 3

Test Name: Validate response schema

Input:GET /api/orders/ORD-1001

Expected Result:

Response contains the following fields:

order_id
customer_id
amount
currency
status
created_at

Ensures all mandatory response fields are present.

Test Case 4

Test Name: Validate amount and currency

Input:GET /api/orders/ORD-1001

Expected Result:
amount = 100.50
currency = GBP

Ensures financial data returned by the API is accurate.

Test Case 5

Test Name: Validate response time

Input:GET /api/orders/ORD-1001

Expected Result:
HTTP Status Code = 200
Response time is less than 2 seconds

Ensures the API performs within an acceptable response time.


API- TASK 2

I used REST ASSURED.

given()
    .baseUri("https://example.com")
.when()
    .get("/api/orders/ORD-1001")
.then()
    .statusCode(200)
    .body("order_id", equalTo("ORD-1001"))
    .body("status", equalTo("PAID"));







