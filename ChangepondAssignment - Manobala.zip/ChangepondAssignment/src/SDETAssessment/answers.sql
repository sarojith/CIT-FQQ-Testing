SQL Task 1 — Price Changes

Write a SQL query to find products whose price changed from yesterday to today.

SELECT
    y.product_id,
    y.product_name,
    y.price AS old_price,
    t.price AS new_price
FROM products_yesterday y
INNER JOIN products_today t
ON y.product_id = t.product_id
WHERE y.price <> t.price;



SQL Task 2 — New Products
Write a SQL query to find products that are new today, meaning they exist in products_today but not in products_yesterday.

SELECT
    t.product_id,
    t.product_name,
    t.price,
    t.status
FROM products_today t
LEFT JOIN products_yesterday y
ON t.product_id = y.product_id
WHERE y.product_id IS NULL;


SQL Task 3 — Missing Products
Write a SQL query to find products that existed yesterday but are missing today.

SELECT
    y.product_id,
    y.product_name,
    y.price,
    y.status
FROM products_yesterday y
LEFT JOIN products_today t
ON y.product_id = t.product_id
WHERE t.product_id IS NULL;



SQL Task 4 — Status Changes
Write a SQL query to find products whose status changed from yesterday to today.

SELECT
    y.product_id,
    y.product_name,
    y.status AS old_status,
    t.status AS new_status
FROM products_yesterday y
INNER JOIN products_today t
ON y.product_id = t.product_id
WHERE y.status <> t.status;

SQL Task 5 — Short Explanation


1. Why did you use INNER JOIN, LEFT JOIN, NOT EXISTS, or another approach?

INNER JOIN is used when comparing products that exist in both tables.
LEFT JOIN is used to find all records from LEFT table and matching records from the right table. Here i used LEFT JOIN for new or missing products by checking for NULL values.

2. What would change if product_id was not unique?

 If product_id is not unique, the JOIN may return duplicate rows. A primary key would be needed to identify each product correctly.



3. What issue could happen if price or status can be NULL?

If price or status is NULL, it may lead to incorrect comparison results and inaccurate reports. 
NULL values should be handled before performing comparisons. It can be  handled using the COALESCE() function.









