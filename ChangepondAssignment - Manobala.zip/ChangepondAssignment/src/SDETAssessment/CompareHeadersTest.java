package SDETAssessment;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

public class CompareHeadersTest {
	
	

	    public static void main(String[] args) {
	        try {
	            System.out.println("=== Running Test Case 1: Identical Headers ===");
	            runTestCase("id,name,email", "id,name,email");

	            System.out.println("\n=== Running Test Case 2: Missing Header ===");
	            runTestCase("id,name,email,age", "id,name,email"); // 'age' is missing in actual

	            System.out.println("\n=== Running Test Case 3: Headers with Extra Spaces ===");
	            runTestCase(" id , name , email ", "id,   name,email"); // Should match perfectly after trimming

	        } catch (IOException e) {
	            System.out.println("Test setup failed due to an I/O error: " + e.getMessage());
	        }
	    }

	    // Helper method to create temporary files, run the test, and delete them
	    private static void runTestCase(String expectedContent, String actualContent) throws IOException {
	        // Create temporary files
	        File expectedFile = File.createTempFile("expected_", ".csv");
	        File actualFile = File.createTempFile("actual_", ".csv");

	        // Write test data to the files
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(expectedFile))) {
	            writer.write(expectedContent);
	        }
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(actualFile))) {
	            writer.write(actualContent);
	        }

	        // Execute the comparison logic
	        CompareHeaders.compareCsvHeaders(expectedFile.getAbsolutePath(), actualFile.getAbsolutePath());

	        // Clean up the temporary files
	        expectedFile.delete();
	        actualFile.delete();
	    }
	}

