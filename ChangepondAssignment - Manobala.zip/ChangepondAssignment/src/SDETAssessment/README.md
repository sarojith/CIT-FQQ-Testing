# README

## 1. Language Used

Programming Language: Java

## How to Compile

```bash
javac -d . src/SDETAssessment/CompareHeaders.java
```

---

## How to Run

```bash
java SDETAssessment.CompareHeaders src/SDETAssessment/expected_orders.csv src/SDETAssessment/actual_orders.csv
```

---

## Running Test Cases

```bash
java SDETAssessment.CompareHeaders src/SDETAssessment/expected1.csv src/SDETAssessment/actual1.csv

java SDETAssessment.CompareHeaders src/SDETAssessment/expected2.csv src/SDETAssessment/actual2.csv

java SDETAssessment.CompareHeaders src/SDETAssessment/expected3.csv src/SDETAssessment/actual3.csv
```

---
## SQL Solution

The SQL queries are available in `answers.sql`.

## API Testing

API test cases are available in `API_Test_Cases.md`.
Includes:

- Five API test cases
- Rest Assured sample test

## Assumptions

- Product IDs are unique.
- CSV files are comma-separated.
- Only the first row is compared.
- Header comparison ignores leading and trailing spaces.

---

## AI Usage

AI tools were used to assist with SQL queries, Java code, documentation, and API test cases.

The final solution was reviewed, understood, and verified before submission.

The complete AI conversation is included in `AI_TRANSCRIPT.md`.


