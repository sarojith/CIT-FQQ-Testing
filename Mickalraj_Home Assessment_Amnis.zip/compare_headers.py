import sys

def read_headers(path):
    with open(path,"r",encoding="utf-8") as f:
        line=f.readline().strip()
        if not line:
            raise ValueError("Empty CSV file")
        headers=[h.strip() for h in line.split(",") if h.strip()]
        if not headers:
            raise ValueError("No valid headers")
        return headers

def compare(expected,actual):
    only_expected=[h for h in expected if h not in actual]
    only_actual=[h for h in actual if h not in expected]
    common=[h for h in expected if h in actual]
    same_order=common==[h for h in actual if h in common]
    return only_expected,only_actual,common,same_order

if __name__=="__main__":
    if len(sys.argv)!=3:
        print("Usage: python compare_headers.py expected.csv actual.csv");sys.exit(1)
    e=read_headers(sys.argv[1]);a=read_headers(sys.argv[2])
    oe,oa,c,s=compare(e,a)
    print("Only expected:",oe)
    print("Only actual:",oa)
    print("Common:",c)
    print("Same relative order:",s)
