-- Task 1
SELECT y.product_id,y.product_name,y.price AS old_price,t.price AS new_price
FROM products_yesterday y
JOIN products_today t ON y.product_id=t.product_id
WHERE y.price<>t.price;

-- Task 2
SELECT t.product_id,t.product_name,t.price,t.status
FROM products_today t
LEFT JOIN products_yesterday y ON t.product_id=y.product_id
WHERE y.product_id IS NULL;

-- Task 3
SELECT y.product_id,y.product_name,y.price,y.status
FROM products_yesterday y
LEFT JOIN products_today t ON y.product_id=t.product_id
WHERE t.product_id IS NULL;

-- Task 4
SELECT y.product_id,y.product_name,y.status AS old_status,t.status AS new_status
FROM products_yesterday y
JOIN products_today t ON y.product_id=t.product_id
WHERE y.status<>t.status;
