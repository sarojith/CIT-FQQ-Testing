# AI_TRANSCRIPT

Tool: ChatGPT

Prompt:
Help me complete the SDET take-home assignment.

Response:
Generated SQL, Python CSV comparison tool, tests, README and guidance.

Manual changes:
Reviewed and verified before submission.
