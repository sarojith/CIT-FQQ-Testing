# SDET Take Home

## Language
Python

## Run
python compare_headers.py expected_orders.csv actual_orders.csv

## Tests
pytest test_compare_headers.py

## Assumptions
- CSV contains header in first row.
- Comma separated values.

## AI Usage
Used ChatGPT to assist with solution.

## Candidate Acknowledgement
I understand and can explain this solution.
