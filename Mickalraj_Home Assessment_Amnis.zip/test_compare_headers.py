from compare_headers import compare
def test_identical():
    assert compare(["a","b"],["a","b"])[3] is True
def test_missing():
    assert "b" in compare(["a","b"],["a"])[0]
def test_order():
    assert compare(["a","b"],["b","a"])[3] is False
